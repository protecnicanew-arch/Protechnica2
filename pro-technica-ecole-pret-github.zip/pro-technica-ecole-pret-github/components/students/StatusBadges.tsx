import { Badge } from "@/components/ui/badge";
import type { Student, PaymentStatus } from "@/lib/types";

export function StudentStatusBadge({ statut }: { statut: Student["statut"] }) {
  const map: Record<Student["statut"], { label: string; variant: any }> = {
    actif: { label: "Actif", variant: "success" },
    suspendu: { label: "Suspendu", variant: "warning" },
    diplome: { label: "Diplômé", variant: "secondary" },
    abandon: { label: "Abandon", variant: "destructive" },
  };
  const { label, variant } = map[statut];
  return <Badge variant={variant}>{label}</Badge>;
}

export function PaymentStatusBadge({ status }: { status: PaymentStatus }) {
  const map: Record<PaymentStatus, { label: string; variant: any }> = {
    paye: { label: "Payé", variant: "success" },
    partiel: { label: "Partiel", variant: "warning" },
    impaye: { label: "Impayé", variant: "destructive" },
    en_retard: { label: "En retard", variant: "destructive" },
  };
  const { label, variant } = map[status];
  return <Badge variant={variant}>{label}</Badge>;
}
