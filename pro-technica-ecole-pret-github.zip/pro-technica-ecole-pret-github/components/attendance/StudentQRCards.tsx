"use client";

import { QRCodeSVG } from "qrcode.react";
import { useState } from "react";
import { Search } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { useAcademicStore } from "@/lib/store";

export function StudentQRCards() {
  const { students, classes } = useAcademicStore();
  const [search, setSearch] = useState("");

  const classeName = (id: string) => classes.find((c) => c.id === id)?.nom ?? "—";

  const filtered = students.filter(
    (s) => search.trim() === "" || s.fullName.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div>
      <div className="flex items-center gap-2 rounded-lg border border-border bg-background px-3 py-2 mb-5 max-w-md">
        <Search className="h-4 w-4 text-muted-foreground shrink-0" />
        <input
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Rechercher un étudiant…"
          className="w-full bg-transparent text-sm outline-none placeholder:text-muted-foreground"
        />
      </div>

      <p className="text-xs text-muted-foreground mb-4">
        Chaque QR code encode le matricule de l'étudiant. En phase 2, le scan appellera directement
        <code className="mx-1 px-1 py-0.5 rounded bg-muted">markAttendance()</code> côté serveur.
      </p>

      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-4">
        {filtered.map((s) => (
          <Card key={s.id} className="premium-gradient text-white">
            <CardContent className="pt-5 flex flex-col items-center text-center">
              <div className="bg-white rounded-lg p-2.5 mb-3">
                <QRCodeSVG value={s.matricule} size={110} fgColor="#111111" bgColor="#FFFFFF" />
              </div>
              <p className="font-semibold text-sm">{s.fullName}</p>
              <p className="text-xs text-white/60">{s.matricule}</p>
              <p className="text-xs text-white/60">{classeName(s.classeId)}</p>
            </CardContent>
          </Card>
        ))}
        {filtered.length === 0 && (
          <p className="text-sm text-muted-foreground col-span-full text-center py-8">
            Aucun étudiant ne correspond à votre recherche.
          </p>
        )}
      </div>
    </div>
  );
}
