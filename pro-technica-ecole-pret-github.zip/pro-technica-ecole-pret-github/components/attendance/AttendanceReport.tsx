"use client";

import { useMemo } from "react";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from "recharts";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useAcademicStore } from "@/lib/store";
import { AttendanceBadge } from "./AttendanceBadge";
import { formatDate } from "@/lib/utils";

export function AttendanceReport() {
  const { classes, students, attendance } = useAcademicStore();

  const rateByClasse = useMemo(() => {
    return classes.map((c) => {
      const records = attendance.filter((a) => a.classeId === c.id && a.personType === "etudiant");
      const presentCount = records.filter((a) => a.status === "present" || a.status === "retard").length;
      const taux = records.length > 0 ? (presentCount / records.length) * 100 : 0;
      return { classe: c.nom, taux: Math.round(taux) };
    });
  }, [classes, attendance]);

  const recent = [...attendance]
    .filter((a) => a.personType === "etudiant")
    .sort((a, b) => (a.date < b.date ? 1 : -1))
    .slice(0, 12);

  const studentName = (id: string) => students.find((s) => s.id === id)?.fullName ?? "—";
  const classeName = (id?: string) => classes.find((c) => c.id === id)?.nom ?? "—";

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader><CardTitle>Taux de présence par classe</CardTitle></CardHeader>
        <CardContent className="pl-0">
          {attendance.length === 0 ? (
            <p className="text-sm text-muted-foreground px-5">
              Aucune présence enregistrée pour le moment. Commencez par une prise de présence.
            </p>
          ) : (
            <ResponsiveContainer width="100%" height={240}>
              <BarChart data={rateByClasse} margin={{ left: 8, right: 16 }}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} className="stroke-border" />
                <XAxis dataKey="classe" tickLine={false} axisLine={false} fontSize={11} />
                <YAxis tickLine={false} axisLine={false} fontSize={12} unit="%" domain={[0, 100]} />
                <Tooltip formatter={(v: number) => `${v}%`} />
                <Bar dataKey="taux" fill="#E10600" radius={[6, 6, 0, 0]} barSize={32} />
              </BarChart>
            </ResponsiveContainer>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader><CardTitle>Historique récent</CardTitle></CardHeader>
        <CardContent className="space-y-2">
          {recent.length === 0 && <p className="text-sm text-muted-foreground">Aucun enregistrement.</p>}
          {recent.map((a) => (
            <div key={a.id} className="flex items-center justify-between rounded-lg border border-border px-4 py-2.5 text-sm">
              <div>
                <p className="font-medium">{studentName(a.personId)}</p>
                <p className="text-xs text-muted-foreground">{classeName(a.classeId)} · {formatDate(a.date)}</p>
              </div>
              <AttendanceBadge status={a.status} />
            </div>
          ))}
        </CardContent>
      </Card>
    </div>
  );
}
