-- ============================================================
-- COMMUNICATION, DOCUMENTS, BIBLIOTHÈQUE, AUDIT, PARAMÈTRES
-- ============================================================
create table public.announcements (
  id uuid primary key default gen_random_uuid(),
  titre text not null,
  contenu text not null,
  auteur_id uuid references public.profiles(id) on delete set null,
  type announcement_type not null default 'annonce',
  image_url text,
  cible_roles user_role[] default null,
  date date not null default current_date,
  created_at timestamptz not null default now()
);

create table public.notifications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  titre text not null,
  message text not null,
  type text not null default 'info',
  lien text,
  lu boolean not null default false,
  created_at timestamptz not null default now()
);

create table public.documents (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid references public.profiles(id) on delete cascade,
  owner_type document_owner_type not null default 'etudiant',
  nom text not null,
  type text,
  storage_path text not null,
  taille_octets bigint,
  uploaded_by uuid references public.profiles(id) on delete set null,
  created_at timestamptz not null default now()
);

create table public.library_resources (
  id uuid primary key default gen_random_uuid(),
  titre text not null,
  auteur text,
  categorie text,
  fichier_url text,
  disponible boolean not null default true,
  created_at timestamptz not null default now()
);

create table public.audit_logs (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references public.profiles(id) on delete set null,
  user_name text,
  action audit_action not null,
  table_name text,
  record_id uuid,
  details jsonb,
  ip_address text,
  created_at timestamptz not null default now()
);

create table public.school_settings (
  id uuid primary key default gen_random_uuid(),
  cle text not null unique,
  valeur jsonb not null,
  updated_by uuid references public.profiles(id) on delete set null,
  updated_at timestamptz not null default now()
);
