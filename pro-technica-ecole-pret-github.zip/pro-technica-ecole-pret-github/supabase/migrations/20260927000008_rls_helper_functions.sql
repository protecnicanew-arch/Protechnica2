-- ============================================================
-- FONCTIONS UTILITAIRES RLS (security definer pour éviter la récursion RLS)
-- ============================================================
create or replace function public.current_role()
returns user_role language sql stable security definer set search_path = public as $$
  select role from public.profiles where id = auth.uid();
$$;

create or replace function public.is_admin_or_direction()
returns boolean language sql stable security definer set search_path = public as $$
  select exists (
    select 1 from public.profiles
    where id = auth.uid() and role in ('administrateur','direction')
  );
$$;

create or replace function public.is_comptable_or_above()
returns boolean language sql stable security definer set search_path = public as $$
  select exists (
    select 1 from public.profiles
    where id = auth.uid() and role in ('administrateur','direction','comptable')
  );
$$;

create or replace function public.is_teacher_of_classe(p_classe_id uuid)
returns boolean language sql stable security definer set search_path = public as $$
  select exists (
    select 1 from public.teacher_classes tc
    where tc.teacher_id = auth.uid() and tc.classe_id = p_classe_id
  ) or exists (
    select 1 from public.classes c
    where c.id = p_classe_id and c.professeur_principal_id = auth.uid()
  );
$$;

create or replace function public.is_teacher_of_student(p_student_id uuid)
returns boolean language sql stable security definer set search_path = public as $$
  select exists (
    select 1 from public.students s
    where s.id = p_student_id and public.is_teacher_of_classe(s.classe_id)
  );
$$;

create or replace function public.is_parent_of_student(p_student_id uuid)
returns boolean language sql stable security definer set search_path = public as $$
  select exists (
    select 1 from public.student_parents sp
    where sp.student_id = p_student_id and sp.parent_id = auth.uid()
  );
$$;
