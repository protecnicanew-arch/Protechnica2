-- ============================================================
-- PRÉSENCES, EXAMENS, NOTES, BULLETINS
-- ============================================================
create table public.attendance (
  id uuid primary key default gen_random_uuid(),
  classe_id uuid references public.classes(id) on delete cascade,
  subject_id uuid references public.subjects(id) on delete set null,
  teacher_id uuid references public.teachers(id) on delete set null,
  date date not null default current_date,
  created_by uuid references public.profiles(id) on delete set null,
  created_at timestamptz not null default now()
);

create table public.attendance_details (
  id uuid primary key default gen_random_uuid(),
  attendance_id uuid not null references public.attendance(id) on delete cascade,
  person_id uuid not null references public.profiles(id) on delete cascade,
  person_type person_type not null,
  status attendance_status not null default 'present',
  justificatif_url text,
  created_at timestamptz not null default now(),
  unique (attendance_id, person_id)
);

create table public.exams (
  id uuid primary key default gen_random_uuid(),
  classe_id uuid not null references public.classes(id) on delete cascade,
  subject_id uuid not null references public.subjects(id) on delete cascade,
  teacher_id uuid references public.teachers(id) on delete set null,
  titre text not null,
  type exam_type not null default 'controle',
  periode text not null,
  bareme numeric(5,2) not null default 20,
  coefficient numeric(4,2) not null default 1,
  date date not null default current_date,
  created_at timestamptz not null default now()
);

create table public.grades (
  id uuid primary key default gen_random_uuid(),
  exam_id uuid not null references public.exams(id) on delete cascade,
  student_id uuid not null references public.students(id) on delete cascade,
  note numeric(5,2) not null,
  commentaire text,
  saisi_par uuid references public.profiles(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (exam_id, student_id),
  constraint grades_note_check check (note >= 0)
);

create table public.report_cards (
  id uuid primary key default gen_random_uuid(),
  student_id uuid not null references public.students(id) on delete cascade,
  periode text not null,
  moyenne_generale numeric(5,2),
  rang smallint,
  effectif_classe smallint,
  appreciation text,
  pdf_url text,
  genere_par uuid references public.profiles(id) on delete set null,
  created_at timestamptz not null default now(),
  unique (student_id, periode)
);
