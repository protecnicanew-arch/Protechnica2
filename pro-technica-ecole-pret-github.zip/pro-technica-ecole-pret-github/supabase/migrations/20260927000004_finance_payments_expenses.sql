-- ============================================================
-- FINANCE : FRAIS, VERSEMENTS, DÉPENSES
-- ============================================================
create table public.payments (
  id uuid primary key default gen_random_uuid(),
  student_id uuid not null references public.students(id) on delete cascade,
  libelle text not null,
  type payment_type not null default 'scolarite',
  montant_du numeric(12,2) not null,
  date_echeance date,
  status payment_status not null default 'impaye',
  created_by uuid references public.profiles(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint payments_montant_check check (montant_du >= 0)
);

create table public.payment_installments (
  id uuid primary key default gen_random_uuid(),
  payment_id uuid not null references public.payments(id) on delete cascade,
  montant numeric(12,2) not null,
  date_paiement date not null default current_date,
  mode_paiement payment_mode not null default 'especes',
  recu_url text,
  recu_numero text unique,
  encaisse_par uuid references public.profiles(id) on delete set null,
  created_at timestamptz not null default now(),
  constraint installments_montant_check check (montant > 0)
);

create table public.expenses (
  id uuid primary key default gen_random_uuid(),
  libelle text not null,
  categorie text not null,
  montant numeric(12,2) not null,
  date date not null default current_date,
  justificatif_url text,
  created_by uuid references public.profiles(id) on delete set null,
  created_at timestamptz not null default now(),
  constraint expenses_montant_check check (montant >= 0)
);
