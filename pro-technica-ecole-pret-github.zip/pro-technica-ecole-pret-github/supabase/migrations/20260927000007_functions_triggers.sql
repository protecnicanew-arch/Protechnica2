-- ============================================================
-- FONCTIONS & TRIGGERS
-- ============================================================
create or replace function public.set_updated_at()
returns trigger language plpgsql as $$
begin
  new.updated_at = now();
  return new;
end; $$;

create trigger trg_profiles_updated_at before update on public.profiles
  for each row execute function public.set_updated_at();
create trigger trg_students_updated_at before update on public.students
  for each row execute function public.set_updated_at();
create trigger trg_grades_updated_at before update on public.grades
  for each row execute function public.set_updated_at();
create trigger trg_payments_updated_at before update on public.payments
  for each row execute function public.set_updated_at();

-- Création automatique du profil à l'inscription Supabase Auth
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id, full_name, email, role)
  values (
    new.id,
    coalesce(new.raw_user_meta_data ->> 'full_name', new.email),
    new.email,
    coalesce((new.raw_user_meta_data ->> 'role')::user_role, 'etudiant')
  )
  on conflict (id) do nothing;
  return new;
end; $$;

create trigger trg_on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

-- Recalcul automatique du solde restant + statut de paiement
create or replace function public.recompute_payment_status()
returns trigger language plpgsql as $$
declare
  v_payment_id uuid;
  v_total_paye numeric(12,2);
  v_montant_du numeric(12,2);
  v_student_id uuid;
begin
  v_payment_id := coalesce(new.payment_id, old.payment_id);

  select montant_du, student_id into v_montant_du, v_student_id
  from public.payments where id = v_payment_id;

  select coalesce(sum(montant), 0) into v_total_paye
  from public.payment_installments where payment_id = v_payment_id;

  update public.payments
  set status = case
      when v_total_paye <= 0 then 'impaye'
      when v_total_paye >= v_montant_du then 'paye'
      else 'partiel'
    end
  where id = v_payment_id;

  update public.students s
  set solde_restant = coalesce((
    select sum(p.montant_du) - coalesce((
      select sum(pi.montant) from public.payment_installments pi
      join public.payments p2 on p2.id = pi.payment_id
      where p2.student_id = s.id
    ), 0)
    from public.payments p
    where p.student_id = s.id
  ), 0)
  where s.id = v_student_id;

  return coalesce(new, old);
end; $$;

create trigger trg_installments_recompute
  after insert or update or delete on public.payment_installments
  for each row execute function public.recompute_payment_status();

-- Journalisation automatique dans audit_logs pour les tables sensibles
create or replace function public.audit_trigger_fn()
returns trigger language plpgsql security definer set search_path = public as $$
declare
  v_action audit_action;
  v_user_id uuid;
  v_user_name text;
begin
  v_user_id := auth.uid();
  select full_name into v_user_name from public.profiles where id = v_user_id;

  if tg_op = 'INSERT' then v_action := 'creation';
  elsif tg_op = 'UPDATE' then v_action := 'modification';
  elsif tg_op = 'DELETE' then v_action := 'suppression';
  end if;

  insert into public.audit_logs (user_id, user_name, action, table_name, record_id, details)
  values (
    v_user_id,
    v_user_name,
    v_action,
    tg_table_name,
    coalesce((case when tg_op = 'DELETE' then old.id else new.id end), null),
    case when tg_op = 'DELETE' then to_jsonb(old) else to_jsonb(new) end
  );

  return coalesce(new, old);
end; $$;

create trigger trg_audit_students
  after insert or update or delete on public.students
  for each row execute function public.audit_trigger_fn();
create trigger trg_audit_payments
  after insert or update or delete on public.payments
  for each row execute function public.audit_trigger_fn();
create trigger trg_audit_installments
  after insert or update or delete on public.payment_installments
  for each row execute function public.audit_trigger_fn();
create trigger trg_audit_grades
  after insert or update or delete on public.grades
  for each row execute function public.audit_trigger_fn();
