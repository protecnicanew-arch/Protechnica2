"use client";

import { useState } from "react";
import { Plus, Pencil, Trash2, Layers } from "lucide-react";
import { DashboardShell } from "@/components/layout/DashboardShell";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { FiliereFormDialog } from "@/components/academic/FiliereFormDialog";
import { useAcademicStore } from "@/lib/store";
import type { Filiere } from "@/lib/types";

export default function FilieresPage() {
  const { filieres, classes, addFiliere, updateFiliere, deleteFiliere } = useAcademicStore();
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editing, setEditing] = useState<Filiere | undefined>(undefined);

  const classCount = (filiereId: string) => classes.filter((c) => c.filiereId === filiereId).length;

  const openCreate = () => { setEditing(undefined); setDialogOpen(true); };
  const openEdit = (f: Filiere) => { setEditing(f); setDialogOpen(true); };

  const handleSubmit = (data: Omit<Filiere, "id">) => {
    if (editing) updateFiliere(editing.id, data);
    else addFiliere(data);
  };

  const handleDelete = (f: Filiere) => {
    if (classCount(f.id) > 0) {
      alert("Impossible de supprimer : des classes sont encore rattachées à cette filière.");
      return;
    }
    if (confirm(`Supprimer la filière "${f.nom}" ?`)) deleteFiliere(f.id);
  };

  return (
    <DashboardShell title="Filières">
      <div className="flex items-center justify-between mb-5">
        <p className="text-sm text-muted-foreground">
          BTS, Licence, Master, formations professionnelles.
        </p>
        <Button onClick={openCreate} className="gap-1.5">
          <Plus className="h-4 w-4" /> Nouvelle filière
        </Button>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-4">
        {filieres.map((f) => (
          <Card key={f.id} className="hover:shadow-elevated transition-shadow">
            <CardContent className="pt-5">
              <div className="flex items-start justify-between mb-2">
                <div className="h-10 w-10 rounded-lg bg-primary/10 flex items-center justify-center">
                  <Layers className="h-5 w-5 text-primary" />
                </div>
                <Badge variant="outline">{f.type}</Badge>
              </div>
              <h3 className="font-semibold mb-1">{f.nom}</h3>
              <p className="text-xs text-muted-foreground mb-3">
                {f.dureeAnnees} an{f.dureeAnnees > 1 ? "s" : ""} · {classCount(f.id)} classe{classCount(f.id) !== 1 ? "s" : ""}
              </p>
              {f.description && <p className="text-xs text-muted-foreground mb-3">{f.description}</p>}
              <div className="flex gap-2">
                <Button variant="outline" size="sm" className="flex-1 gap-1.5" onClick={() => openEdit(f)}>
                  <Pencil className="h-3.5 w-3.5" /> Modifier
                </Button>
                <Button variant="ghost" size="sm" className="text-red-600 hover:text-red-700" onClick={() => handleDelete(f)}>
                  <Trash2 className="h-3.5 w-3.5" />
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <FiliereFormDialog
        open={dialogOpen}
        onClose={() => setDialogOpen(false)}
        onSubmit={handleSubmit}
        initial={editing}
      />
    </DashboardShell>
  );
}
