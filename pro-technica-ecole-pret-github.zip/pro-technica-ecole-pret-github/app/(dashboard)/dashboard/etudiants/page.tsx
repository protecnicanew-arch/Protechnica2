"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { UserPlus } from "lucide-react";
import { DashboardShell } from "@/components/layout/DashboardShell";
import { StudentsTable } from "@/components/students/StudentsTable";
import { Button } from "@/components/ui/button";
import { getStudents, getClasses } from "@/lib/data";
import type { Student, Classe } from "@/lib/types";

export default function EtudiantsPage() {
  const [students, setStudents] = useState<Student[]>([]);
  const [classes, setClasses] = useState<Classe[]>([]);

  useEffect(() => {
    getStudents().then(setStudents);
    getClasses().then(setClasses);
  }, []);

  return (
    <DashboardShell title="Étudiants">
      <div className="flex items-center justify-between mb-5">
        <p className="text-sm text-muted-foreground">
          Gérez les inscriptions, profils et dossiers de vos étudiants.
        </p>
        <Link href="/dashboard/etudiants/nouveau">
          <Button className="gap-1.5">
            <UserPlus className="h-4 w-4" /> Nouvel étudiant
          </Button>
        </Link>
      </div>

      <StudentsTable students={students} classes={classes} />
    </DashboardShell>
  );
}
