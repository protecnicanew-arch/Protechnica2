"use client";

import { useEffect, useRef, useState } from "react";
import { useParams, useRouter } from "next/navigation";
import { ArrowLeft, Mail, Phone, Calendar, FileText, Download, Upload, Trash2 } from "lucide-react";
import { DashboardShell } from "@/components/layout/DashboardShell";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { StudentStatusBadge, PaymentStatusBadge } from "@/components/students/StatusBadges";
import {
  getStudentById, getPaymentsByStudent, getGradesByStudent, getClasseById, getFiliereById,
} from "@/lib/data";
import {
  listDocumentsForOwner, uploadDocument, downloadDocument, deleteDocument, type StudentDocument,
} from "@/lib/services/documents.service";
import { useSession } from "@/lib/auth/use-session";
import type { Student, Payment, Grade } from "@/lib/types";
import { formatCFA, formatDate } from "@/lib/utils";

type Tab = "infos" | "academique" | "paiements" | "documents";

export default function EtudiantProfilPage() {
  const params = useParams<{ id: string }>();
  const router = useRouter();
  const [student, setStudent] = useState<Student | null | undefined>(undefined);
  const [payments, setPayments] = useState<Payment[]>([]);
  const [grades, setGrades] = useState<Grade[]>([]);
  const [tab, setTab] = useState<Tab>("infos");
  const [documents, setDocuments] = useState<StudentDocument[]>([]);
  const [uploading, setUploading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { profile } = useSession();

  useEffect(() => {
    getStudentById(params.id).then(setStudent);
    getPaymentsByStudent(params.id).then(setPayments);
    getGradesByStudent(params.id).then(setGrades);
    listDocumentsForOwner(params.id).then(setDocuments);
  }, [params.id]);

  const reloadDocuments = () => listDocumentsForOwner(params.id).then(setDocuments);

  const handleFileSelected = async (file: File | undefined) => {
    if (!file || !profile) return;
    setUploading(true);
    try {
      await uploadDocument({ ownerId: params.id, ownerType: "etudiant", file, nom: file.name, uploadedBy: profile.id });
      await reloadDocuments();
    } catch (err) {
      alert(err instanceof Error ? err.message : "Échec de l'envoi du fichier.");
    } finally {
      setUploading(false);
      if (fileInputRef.current) fileInputRef.current.value = "";
    }
  };

  const handleDownload = async (doc: StudentDocument) => {
    const url = await downloadDocument(doc.storagePath);
    window.open(url, "_blank");
  };

  const handleDelete = async (doc: StudentDocument) => {
    if (!confirm(`Supprimer "${doc.nom}" ?`)) return;
    await deleteDocument(doc.id, doc.storagePath);
    reloadDocuments();
  };

  if (student === undefined) {
    return (
      <DashboardShell title="Étudiant">
        <p className="text-sm text-muted-foreground">Chargement…</p>
      </DashboardShell>
    );
  }

  if (student === null) {
    return (
      <DashboardShell title="Étudiant introuvable">
        <p className="text-sm text-muted-foreground mb-4">Cet étudiant n'existe pas ou a été supprimé.</p>
        <Button variant="outline" onClick={() => router.push("/dashboard/etudiants")} className="gap-1.5">
          <ArrowLeft className="h-4 w-4" /> Retour à la liste
        </Button>
      </DashboardShell>
    );
  }

  const classe = getClasseById(student.classeId);
  const filiere = getFiliereById(student.filiereId);
  const moyenneGenerale =
    grades.length > 0
      ? grades.reduce((sum, g) => sum + (g.note / g.bareme) * 20 * g.coefficient, 0) /
        grades.reduce((sum, g) => sum + g.coefficient, 0)
      : null;

  const tabs: { id: Tab; label: string }[] = [
    { id: "infos", label: "Informations" },
    { id: "academique", label: "Historique académique" },
    { id: "paiements", label: "Paiements" },
    { id: "documents", label: "Documents" },
  ];

  return (
    <DashboardShell title="Fiche étudiant">
      <Button variant="ghost" size="sm" className="gap-1.5 mb-4 -ml-2" onClick={() => router.push("/dashboard/etudiants")}>
        <ArrowLeft className="h-4 w-4" /> Retour aux étudiants
      </Button>

      <Card className="mb-6">
        <CardContent className="pt-6 flex flex-col sm:flex-row sm:items-center gap-4">
          <div className="h-16 w-16 rounded-full bg-primary/10 flex items-center justify-center text-xl font-semibold text-primary shrink-0">
            {student.fullName.split(" ").map((n) => n[0]).join("").slice(0, 2)}
          </div>
          <div className="flex-1">
            <div className="flex items-center gap-2 flex-wrap">
              <h2 className="text-lg font-semibold">{student.fullName}</h2>
              <StudentStatusBadge statut={student.statut} />
            </div>
            <p className="text-sm text-muted-foreground">{student.matricule} · {classe?.nom} · {filiere?.nom}</p>
            <div className="flex flex-wrap gap-x-4 gap-y-1 mt-2 text-xs text-muted-foreground">
              <span className="flex items-center gap-1"><Mail className="h-3.5 w-3.5" /> {student.email}</span>
              <span className="flex items-center gap-1"><Phone className="h-3.5 w-3.5" /> {student.phone}</span>
              <span className="flex items-center gap-1"><Calendar className="h-3.5 w-3.5" /> Inscrit le {formatDate(student.dateInscription)}</span>
            </div>
          </div>
          <div className="text-right">
            <p className="text-xs text-muted-foreground">Solde restant</p>
            <p className={`text-lg font-semibold ${student.soldeRestant > 0 ? "text-red-600" : "text-emerald-600"}`}>
              {formatCFA(student.soldeRestant)}
            </p>
          </div>
        </CardContent>
      </Card>

      <div className="flex gap-1 border-b border-border mb-5 overflow-x-auto">
        {tabs.map((t) => (
          <button
            key={t.id}
            onClick={() => setTab(t.id)}
            className={`px-4 py-2.5 text-sm font-medium whitespace-nowrap border-b-2 -mb-px transition-colors ${
              tab === t.id
                ? "border-primary text-primary"
                : "border-transparent text-muted-foreground hover:text-foreground"
            }`}
          >
            {t.label}
          </button>
        ))}
      </div>

      {tab === "infos" && (
        <Card>
          <CardHeader><CardTitle>Informations personnelles</CardTitle></CardHeader>
          <CardContent className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-sm">
            <InfoRow label="Nom complet" value={student.fullName} />
            <InfoRow label="Matricule" value={student.matricule} />
            <InfoRow label="Date de naissance" value={formatDate(student.dateNaissance)} />
            <InfoRow label="Classe" value={classe?.nom ?? "—"} />
            <InfoRow label="Filière" value={filiere?.nom ?? "—"} />
            <InfoRow label="Email" value={student.email} />
            <InfoRow label="Téléphone" value={student.phone} />
            <InfoRow label="Date d'inscription" value={formatDate(student.dateInscription)} />
          </CardContent>
        </Card>
      )}

      {tab === "academique" && (
        <Card>
          <CardHeader className="flex flex-row items-center justify-between">
            <CardTitle>Notes & évaluations</CardTitle>
            {moyenneGenerale !== null && (
              <span className="text-sm font-semibold">
                Moyenne générale : <span className="text-primary">{moyenneGenerale.toFixed(2)}/20</span>
              </span>
            )}
          </CardHeader>
          <CardContent>
            {grades.length === 0 ? (
              <p className="text-sm text-muted-foreground">Aucune note enregistrée.</p>
            ) : (
              <div className="space-y-2">
                {grades.map((g) => (
                  <div key={g.id} className="flex items-center justify-between rounded-lg border border-border px-4 py-3 text-sm">
                    <div>
                      <p className="font-medium">{g.matiere}</p>
                      <p className="text-xs text-muted-foreground capitalize">{g.type} · {formatDate(g.date)}</p>
                    </div>
                    <span className="font-semibold">{g.note}/{g.bareme}</span>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {tab === "paiements" && (
        <Card>
          <CardHeader><CardTitle>Historique des paiements</CardTitle></CardHeader>
          <CardContent>
            {payments.length === 0 ? (
              <p className="text-sm text-muted-foreground">Aucun paiement enregistré.</p>
            ) : (
              <div className="space-y-2">
                {payments.map((p) => (
                  <div key={p.id} className="flex items-center justify-between rounded-lg border border-border px-4 py-3 text-sm">
                    <div>
                      <p className="font-medium">{p.libelle}</p>
                      <p className="text-xs text-muted-foreground">{formatDate(p.date)}</p>
                    </div>
                    <div className="flex items-center gap-3">
                      <span className="text-right">
                        <span className="font-semibold">{formatCFA(p.montantPaye)}</span>
                        <span className="text-muted-foreground"> / {formatCFA(p.montantDu)}</span>
                      </span>
                      <PaymentStatusBadge status={p.status} />
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {tab === "documents" && (
        <Card>
          <CardHeader className="flex flex-row items-center justify-between">
            <CardTitle>Documents</CardTitle>
            <div>
              <input
                ref={fileInputRef}
                type="file"
                className="hidden"
                onChange={(e) => handleFileSelected(e.target.files?.[0])}
              />
              <Button size="sm" className="gap-1.5" disabled={uploading} onClick={() => fileInputRef.current?.click()}>
                <Upload className="h-3.5 w-3.5" /> {uploading ? "Envoi…" : "Ajouter un document"}
              </Button>
            </div>
          </CardHeader>
          <CardContent className="space-y-2">
            {documents.length === 0 && (
              <p className="text-sm text-muted-foreground">Aucun document déposé pour cet étudiant.</p>
            )}
            {documents.map((doc) => (
              <div key={doc.id} className="flex items-center justify-between rounded-lg border border-border px-4 py-3 text-sm">
                <span className="flex items-center gap-2 min-w-0">
                  <FileText className="h-4 w-4 text-muted-foreground shrink-0" />
                  <span className="truncate">{doc.nom}</span>
                  <span className="text-xs text-muted-foreground shrink-0">{formatDate(doc.createdAt)}</span>
                </span>
                <div className="flex items-center gap-1 shrink-0">
                  <Button variant="ghost" size="sm" className="gap-1.5" onClick={() => handleDownload(doc)}>
                    <Download className="h-3.5 w-3.5" /> Télécharger
                  </Button>
                  <Button variant="ghost" size="icon" className="text-red-600 hover:text-red-700" onClick={() => handleDelete(doc)}>
                    <Trash2 className="h-3.5 w-3.5" />
                  </Button>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      )}
    </DashboardShell>
  );
}

function InfoRow({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <p className="text-xs text-muted-foreground">{label}</p>
      <p className="font-medium">{value}</p>
    </div>
  );
}
