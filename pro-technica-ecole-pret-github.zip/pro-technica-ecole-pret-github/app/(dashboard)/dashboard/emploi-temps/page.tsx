"use client";

import { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Plus, Trash2, Clock } from "lucide-react";
import { DashboardShell } from "@/components/layout/DashboardShell";
import { Button } from "@/components/ui/button";
import { Dialog } from "@/components/ui/dialog";
import { listScheduleByClasse, createScheduleSlot, deleteScheduleSlot } from "@/lib/services/schedules.service";
import { listSubjects } from "@/lib/services/academic.service";
import { useAcademicStore } from "@/lib/store";
import { useSession } from "@/lib/auth/use-session";
import { can } from "@/lib/auth/permissions";
import type { ScheduleSlot } from "@/lib/types";

const JOURS: ScheduleSlot["jour"][] = ["Lundi", "Mardi", "Mercredi", "Jeudi", "Vendredi", "Samedi"];

const schema = z.object({
  subjectId: z.string().min(1, "Choisissez une matière"),
  teacherId: z.string().min(1, "Choisissez un professeur"),
  jour: z.enum(["Lundi", "Mardi", "Mercredi", "Jeudi", "Vendredi", "Samedi"]),
  heureDebut: z.string().min(1, "Heure de début requise"),
  heureFin: z.string().min(1, "Heure de fin requise"),
  salle: z.string().optional(),
});
type FormValues = z.infer<typeof schema>;

export default function EmploiTempsPage() {
  const { profile } = useSession();
  const { classes, teachers, init } = useAcademicStore();
  const [classeId, setClasseId] = useState("");
  const [subjects, setSubjects] = useState<{ id: string; nom: string }[]>([]);
  const [slots, setSlots] = useState<ScheduleSlot[]>([]);
  const [open, setOpen] = useState(false);

  useEffect(() => { init(); }, [init]);
  useEffect(() => { if (!classeId && classes.length > 0) setClasseId(classes[0].id); }, [classes, classeId]);
  useEffect(() => { listSubjects().then((rows) => setSubjects(rows.map((r) => ({ id: r.id, nom: r.nom })))); }, []);

  const reload = () => { if (classeId) listScheduleByClasse(classeId).then(setSlots); };
  useEffect(reload, [classeId]);

  const canEdit = profile ? can(profile.role, "emploi_temps", "creer") : false;

  const { register, handleSubmit, reset, formState: { errors } } = useForm<FormValues>({ resolver: zodResolver(schema) });

  const submit = async (data: FormValues) => {
    await createScheduleSlot({ classeId, ...data });
    reset();
    setOpen(false);
    reload();
  };

  const remove = async (id: string) => {
    if (!confirm("Supprimer ce créneau ?")) return;
    await deleteScheduleSlot(id);
    reload();
  };

  const teacherName = (id: string) => teachers.find((t) => t.id === id)?.fullName ?? "—";

  return (
    <DashboardShell title="Emploi du temps">
      <div className="flex flex-col sm:flex-row sm:items-center gap-3 mb-5">
        <p className="text-sm text-muted-foreground flex-1">Créneaux hebdomadaires par classe.</p>
        <select className="input sm:w-64" value={classeId} onChange={(e) => setClasseId(e.target.value)}>
          {classes.map((c) => <option key={c.id} value={c.id}>{c.nom}</option>)}
        </select>
        {canEdit && (
          <Button onClick={() => setOpen(true)} className="gap-1.5 shrink-0">
            <Plus className="h-4 w-4" /> Nouveau créneau
          </Button>
        )}
      </div>

      <div className="space-y-4">
        {JOURS.map((jour) => {
          const daySlots = slots.filter((s) => s.jour === jour).sort((a, b) => a.heureDebut.localeCompare(b.heureDebut));
          if (daySlots.length === 0) return null;
          return (
            <div key={jour}>
              <p className="text-xs font-semibold uppercase text-muted-foreground tracking-wide mb-1.5">{jour}</p>
              <div className="space-y-1.5">
                {daySlots.map((s) => (
                  <div key={s.id} className="flex items-center justify-between rounded-lg border border-border bg-card px-4 py-3 text-sm">
                    <div>
                      <p className="font-medium">{s.matiere} — {teacherName(s.teacherId)}</p>
                      {s.salle && <p className="text-xs text-muted-foreground">Salle {s.salle}</p>}
                    </div>
                    <div className="flex items-center gap-3 shrink-0">
                      <span className="flex items-center gap-1.5 text-xs text-muted-foreground">
                        <Clock className="h-3.5 w-3.5" /> {s.heureDebut} – {s.heureFin}
                      </span>
                      {canEdit && (
                        <Button variant="ghost" size="icon" className="text-red-600 hover:text-red-700" onClick={() => remove(s.id)}>
                          <Trash2 className="h-3.5 w-3.5" />
                        </Button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          );
        })}
        {slots.length === 0 && <p className="text-sm text-muted-foreground text-center py-8">Aucun créneau planifié pour cette classe.</p>}
      </div>

      <Dialog open={open} onClose={() => setOpen(false)} title="Nouveau créneau">
        <form onSubmit={handleSubmit(submit)} className="space-y-4">
          <div>
            <label className="text-sm font-medium mb-1.5 block">Matière</label>
            <select className="input" {...register("subjectId")}>
              {subjects.map((s) => <option key={s.id} value={s.id}>{s.nom}</option>)}
            </select>
            {errors.subjectId && <p className="text-xs text-red-600 mt-1">{errors.subjectId.message}</p>}
          </div>
          <div>
            <label className="text-sm font-medium mb-1.5 block">Professeur</label>
            <select className="input" {...register("teacherId")}>
              {teachers.map((t) => <option key={t.id} value={t.id}>{t.fullName}</option>)}
            </select>
            {errors.teacherId && <p className="text-xs text-red-600 mt-1">{errors.teacherId.message}</p>}
          </div>
          <div>
            <label className="text-sm font-medium mb-1.5 block">Jour</label>
            <select className="input" {...register("jour")}>
              {JOURS.map((j) => <option key={j} value={j}>{j}</option>)}
            </select>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="text-sm font-medium mb-1.5 block">Heure de début</label>
              <input type="time" className="input" {...register("heureDebut")} />
              {errors.heureDebut && <p className="text-xs text-red-600 mt-1">{errors.heureDebut.message}</p>}
            </div>
            <div>
              <label className="text-sm font-medium mb-1.5 block">Heure de fin</label>
              <input type="time" className="input" {...register("heureFin")} />
              {errors.heureFin && <p className="text-xs text-red-600 mt-1">{errors.heureFin.message}</p>}
            </div>
          </div>
          <div>
            <label className="text-sm font-medium mb-1.5 block">Salle</label>
            <input className="input" placeholder="Ex: B12" {...register("salle")} />
          </div>
          <div className="flex gap-2 pt-2">
            <Button type="button" variant="outline" className="flex-1" onClick={() => setOpen(false)}>Annuler</Button>
            <Button type="submit" className="flex-1">Créer</Button>
          </div>
        </form>
      </Dialog>
    </DashboardShell>
  );
}
