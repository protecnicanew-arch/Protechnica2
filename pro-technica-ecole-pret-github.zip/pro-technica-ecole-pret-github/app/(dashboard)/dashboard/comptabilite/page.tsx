"use client";

import { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Plus, Trash2 } from "lucide-react";
import { DashboardShell } from "@/components/layout/DashboardShell";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Dialog } from "@/components/ui/dialog";
import { listExpenses, createExpense, deleteExpense, getFinancialReport, type Expense } from "@/lib/services/comptabilite.service";
import { useSession } from "@/lib/auth/use-session";
import { formatCFA, formatDate } from "@/lib/utils";

const schema = z.object({
  libelle: z.string().min(2, "Libellé requis"),
  categorie: z.string().min(2, "Catégorie requise"),
  montant: z.coerce.number().min(1, "Montant requis"),
  date: z.string().min(1, "Date requise"),
});
type FormValues = z.infer<typeof schema>;

export default function ComptabilitePage() {
  const { profile } = useSession();
  const [expenses, setExpenses] = useState<Expense[]>([]);
  const [report, setReport] = useState<{ totalRecettes: number; totalDepenses: number; solde: number } | null>(null);
  const [loading, setLoading] = useState(true);
  const [open, setOpen] = useState(false);
  const { register, handleSubmit, reset, formState: { errors } } = useForm<FormValues>({ resolver: zodResolver(schema) });

  const monthStart = new Date(new Date().getFullYear(), new Date().getMonth(), 1).toISOString().slice(0, 10);
  const today = new Date().toISOString().slice(0, 10);

  const reload = () => {
    setLoading(true);
    Promise.all([listExpenses(), getFinancialReport(monthStart, today)]).then(([exp, rep]) => {
      setExpenses(exp);
      setReport(rep);
      setLoading(false);
    });
  };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  useEffect(reload, []);

  const submit = async (data: FormValues) => {
    if (!profile) return;
    await createExpense({ ...data, createdBy: profile.id });
    reset();
    setOpen(false);
    reload();
  };

  const remove = async (id: string) => {
    if (!confirm("Supprimer cette dépense ?")) return;
    await deleteExpense(id);
    reload();
  };

  return (
    <DashboardShell title="Comptabilité">
      <div className="flex items-center justify-between mb-5">
        <p className="text-sm text-muted-foreground">Dépenses et bilan recettes/dépenses du mois en cours.</p>
        <Button onClick={() => setOpen(true)} className="gap-1.5">
          <Plus className="h-4 w-4" /> Nouvelle dépense
        </Button>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-6">
        <Card><CardContent className="pt-5">
          <p className="text-xs text-muted-foreground mb-1">Recettes du mois</p>
          <p className="text-lg font-semibold text-emerald-600">{formatCFA(report?.totalRecettes ?? 0)}</p>
        </CardContent></Card>
        <Card><CardContent className="pt-5">
          <p className="text-xs text-muted-foreground mb-1">Dépenses du mois</p>
          <p className="text-lg font-semibold text-red-600">{formatCFA(report?.totalDepenses ?? 0)}</p>
        </CardContent></Card>
        <Card><CardContent className="pt-5">
          <p className="text-xs text-muted-foreground mb-1">Solde</p>
          <p className="text-lg font-semibold">{formatCFA(report?.solde ?? 0)}</p>
        </CardContent></Card>
      </div>

      <div className="overflow-x-auto rounded-xl border border-border bg-card">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-border text-left text-muted-foreground">
              <th className="px-4 py-3 font-medium">Libellé</th>
              <th className="px-4 py-3 font-medium">Catégorie</th>
              <th className="px-4 py-3 font-medium">Date</th>
              <th className="px-4 py-3 font-medium">Montant</th>
              <th className="px-4 py-3 font-medium"></th>
            </tr>
          </thead>
          <tbody>
            {expenses.map((e) => (
              <tr key={e.id} className="border-b border-border last:border-0 hover:bg-muted/40">
                <td className="px-4 py-3 whitespace-nowrap font-medium">{e.libelle}</td>
                <td className="px-4 py-3 whitespace-nowrap">{e.categorie}</td>
                <td className="px-4 py-3 whitespace-nowrap">{formatDate(e.date)}</td>
                <td className="px-4 py-3 whitespace-nowrap text-red-600">{formatCFA(e.montant)}</td>
                <td className="px-4 py-3 text-right">
                  <Button variant="ghost" size="icon" className="text-red-600 hover:text-red-700" onClick={() => remove(e.id)}>
                    <Trash2 className="h-3.5 w-3.5" />
                  </Button>
                </td>
              </tr>
            ))}
            {!loading && expenses.length === 0 && (
              <tr><td colSpan={5} className="text-center py-8 text-muted-foreground">Aucune dépense enregistrée.</td></tr>
            )}
          </tbody>
        </table>
      </div>

      <Dialog open={open} onClose={() => setOpen(false)} title="Nouvelle dépense">
        <form onSubmit={handleSubmit(submit)} className="space-y-4">
          <div>
            <label className="text-sm font-medium mb-1.5 block">Libellé</label>
            <input className="input" placeholder="Ex: Facture EDG — Électricité" {...register("libelle")} />
            {errors.libelle && <p className="text-xs text-red-600 mt-1">{errors.libelle.message}</p>}
          </div>
          <div>
            <label className="text-sm font-medium mb-1.5 block">Catégorie</label>
            <input className="input" placeholder="Ex: Charges, Fournitures, Salaires…" {...register("categorie")} />
            {errors.categorie && <p className="text-xs text-red-600 mt-1">{errors.categorie.message}</p>}
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="text-sm font-medium mb-1.5 block">Montant (FCFA)</label>
              <input type="number" className="input" {...register("montant")} />
              {errors.montant && <p className="text-xs text-red-600 mt-1">{errors.montant.message}</p>}
            </div>
            <div>
              <label className="text-sm font-medium mb-1.5 block">Date</label>
              <input type="date" className="input" {...register("date")} />
              {errors.date && <p className="text-xs text-red-600 mt-1">{errors.date.message}</p>}
            </div>
          </div>
          <div className="flex gap-2 pt-2">
            <Button type="button" variant="outline" className="flex-1" onClick={() => setOpen(false)}>Annuler</Button>
            <Button type="submit" className="flex-1">Enregistrer</Button>
          </div>
        </form>
      </Dialog>
    </DashboardShell>
  );
}
