"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { UserPlus } from "lucide-react";
import { DashboardShell } from "@/components/layout/DashboardShell";
import { TeachersGrid } from "@/components/teachers/TeachersGrid";
import { Button } from "@/components/ui/button";
import { getTeachers, getClasses } from "@/lib/data";
import type { Teacher, Classe } from "@/lib/types";

export default function ProfesseursPage() {
  const [teachers, setTeachers] = useState<Teacher[]>([]);
  const [classes, setClasses] = useState<Classe[]>([]);

  useEffect(() => {
    getTeachers().then(setTeachers);
    getClasses().then(setClasses);
  }, []);

  return (
    <DashboardShell title="Professeurs">
      <div className="flex items-center justify-between mb-5">
        <p className="text-sm text-muted-foreground">
          Corps enseignant, matières et affectations aux classes.
        </p>
        <Link href="/dashboard/professeurs/nouveau">
          <Button className="gap-1.5">
            <UserPlus className="h-4 w-4" /> Nouveau professeur
          </Button>
        </Link>
      </div>

      <TeachersGrid teachers={teachers} classes={classes} />
    </DashboardShell>
  );
}
