"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { ArrowLeft } from "lucide-react";
import { DashboardShell } from "@/components/layout/DashboardShell";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { TeacherFormDialog } from "@/components/teachers/TeacherFormDialog";
import { createTeacherAccount } from "@/lib/services/admin-users.service";
import { listSubjects } from "@/lib/services/academic.service";
import { useAcademicStore } from "@/lib/store";

export default function NouveauProfesseurPage() {
  const router = useRouter();
  const { classes } = useAcademicStore();
  const [subjects, setSubjects] = useState<{ id: string; nom: string }[]>([]);

  useEffect(() => {
    listSubjects().then((rows) => setSubjects(rows.map((r) => ({ id: r.id, nom: r.nom }))));
  }, []);

  return (
    <DashboardShell title="Nouveau professeur">
      <Button variant="ghost" size="sm" className="gap-1.5 mb-4 -ml-2" onClick={() => router.push("/dashboard/professeurs")}>
        <ArrowLeft className="h-4 w-4" /> Retour aux professeurs
      </Button>

      <Card>
        <CardContent className="pt-6">
          <TeacherFormDialog
            classes={classes}
            subjects={subjects}
            onSubmit={async (data) => {
              await createTeacherAccount(data);
              router.push("/dashboard/professeurs");
            }}
          />
        </CardContent>
      </Card>
    </DashboardShell>
  );
}
