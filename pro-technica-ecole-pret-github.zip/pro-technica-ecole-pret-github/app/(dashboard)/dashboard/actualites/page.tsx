"use client";

import { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Plus, Trash2, Newspaper } from "lucide-react";
import { DashboardShell } from "@/components/layout/DashboardShell";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Dialog } from "@/components/ui/dialog";
import { listAnnouncements, createAnnouncement, deleteAnnouncement } from "@/lib/services/announcements.service";
import { useSession } from "@/lib/auth/use-session";
import { can } from "@/lib/auth/permissions";
import type { Actualite } from "@/lib/types";
import { formatDate } from "@/lib/utils";

const schema = z.object({
  titre: z.string().min(2, "Titre requis"),
  contenu: z.string().min(5, "Contenu requis"),
  type: z.enum(["annonce", "evenement", "publication"]),
});
type FormValues = z.infer<typeof schema>;

const TYPE_LABEL: Record<Actualite["type"], string> = {
  annonce: "Annonce",
  evenement: "Événement",
  publication: "Publication",
};

export default function ActualitesPage() {
  const { profile } = useSession();
  const [items, setItems] = useState<Actualite[]>([]);
  const [loading, setLoading] = useState(true);
  const [open, setOpen] = useState(false);
  const { register, handleSubmit, reset, formState: { errors } } = useForm<FormValues>({ resolver: zodResolver(schema) });

  const reload = () => {
    setLoading(true);
    listAnnouncements().then((rows) => {
      setItems(rows);
      setLoading(false);
    });
  };
  useEffect(reload, []);

  const canWrite = profile ? can(profile.role, "actualites", "creer") : false;

  const submit = async (data: FormValues) => {
    if (!profile) return;
    await createAnnouncement({ ...data, auteurId: profile.id });
    reset();
    setOpen(false);
    reload();
  };

  const remove = async (id: string) => {
    if (!confirm("Supprimer cette publication ?")) return;
    await deleteAnnouncement(id);
    reload();
  };

  return (
    <DashboardShell title="Actualités">
      <div className="flex items-center justify-between mb-5">
        <p className="text-sm text-muted-foreground">Annonces, événements et publications de l'école.</p>
        {canWrite && (
          <Button onClick={() => setOpen(true)} className="gap-1.5">
            <Plus className="h-4 w-4" /> Nouvelle publication
          </Button>
        )}
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-4">
        {items.map((a) => (
          <Card key={a.id}>
            <CardContent className="pt-5">
              <div className="flex items-start justify-between mb-2">
                <div className="h-10 w-10 rounded-lg bg-primary/10 flex items-center justify-center">
                  <Newspaper className="h-5 w-5 text-primary" />
                </div>
                <Badge variant="outline">{TYPE_LABEL[a.type]}</Badge>
              </div>
              <h3 className="font-semibold mb-1">{a.titre}</h3>
              <p className="text-xs text-muted-foreground mb-2">{formatDate(a.date)}</p>
              <p className="text-sm text-muted-foreground line-clamp-3 mb-3">{a.contenu}</p>
              {canWrite && (
                <Button variant="ghost" size="sm" className="text-red-600 hover:text-red-700 -ml-2" onClick={() => remove(a.id)}>
                  <Trash2 className="h-3.5 w-3.5" /> Supprimer
                </Button>
              )}
            </CardContent>
          </Card>
        ))}
        {!loading && items.length === 0 && (
          <p className="text-sm text-muted-foreground col-span-full text-center py-8">Aucune publication pour le moment.</p>
        )}
      </div>

      <Dialog open={open} onClose={() => setOpen(false)} title="Nouvelle publication">
        <form onSubmit={handleSubmit(submit)} className="space-y-4">
          <div>
            <label className="text-sm font-medium mb-1.5 block">Titre</label>
            <input className="input" {...register("titre")} />
            {errors.titre && <p className="text-xs text-red-600 mt-1">{errors.titre.message}</p>}
          </div>
          <div>
            <label className="text-sm font-medium mb-1.5 block">Type</label>
            <select className="input" {...register("type")}>
              <option value="annonce">Annonce</option>
              <option value="evenement">Événement</option>
              <option value="publication">Publication</option>
            </select>
          </div>
          <div>
            <label className="text-sm font-medium mb-1.5 block">Contenu</label>
            <textarea rows={4} className="input" {...register("contenu")} />
            {errors.contenu && <p className="text-xs text-red-600 mt-1">{errors.contenu.message}</p>}
          </div>
          <div className="flex gap-2 pt-2">
            <Button type="button" variant="outline" className="flex-1" onClick={() => setOpen(false)}>Annuler</Button>
            <Button type="submit" className="flex-1">Publier</Button>
          </div>
        </form>
      </Dialog>
    </DashboardShell>
  );
}
