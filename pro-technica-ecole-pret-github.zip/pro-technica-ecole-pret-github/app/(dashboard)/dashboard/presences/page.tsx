"use client";

import { useState } from "react";
import { DashboardShell } from "@/components/layout/DashboardShell";
import { AttendanceSessionForm } from "@/components/attendance/AttendanceSessionForm";
import { AttendanceReport } from "@/components/attendance/AttendanceReport";
import { StudentQRCards } from "@/components/attendance/StudentQRCards";

type Tab = "saisie" | "rapports" | "qr";

export default function PresencesPage() {
  const [tab, setTab] = useState<Tab>("saisie");

  const tabs: { id: Tab; label: string }[] = [
    { id: "saisie", label: "Prise de présence" },
    { id: "rapports", label: "Rapports & statistiques" },
    { id: "qr", label: "Cartes QR" },
  ];

  return (
    <DashboardShell title="Présences">
      <div className="flex gap-1 border-b border-border mb-5 overflow-x-auto">
        {tabs.map((t) => (
          <button
            key={t.id}
            onClick={() => setTab(t.id)}
            className={`px-4 py-2.5 text-sm font-medium whitespace-nowrap border-b-2 -mb-px transition-colors ${
              tab === t.id ? "border-primary text-primary" : "border-transparent text-muted-foreground hover:text-foreground"
            }`}
          >
            {t.label}
          </button>
        ))}
      </div>

      {tab === "saisie" && <AttendanceSessionForm />}
      {tab === "rapports" && <AttendanceReport />}
      {tab === "qr" && <StudentQRCards />}
    </DashboardShell>
  );
}
