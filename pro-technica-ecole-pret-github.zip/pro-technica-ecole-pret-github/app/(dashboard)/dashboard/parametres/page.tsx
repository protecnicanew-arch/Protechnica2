"use client";

import { useEffect, useState } from "react";
import { DashboardShell } from "@/components/layout/DashboardShell";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { getSettings, setSetting } from "@/lib/services/settings.service";
import { useSession } from "@/lib/auth/use-session";
import { can } from "@/lib/auth/permissions";

export default function ParametresPage() {
  const { profile } = useSession();
  const [nomEcole, setNomEcole] = useState("");
  const [anneeActive, setAnneeActive] = useState("");
  const [seuilRetard, setSeuilRetard] = useState("15");
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    getSettings().then((s) => {
      setNomEcole((s.nom_ecole as string) ?? "PRO TECHNICA ÉCOLE");
      setAnneeActive((s.annee_scolaire_active as string) ?? "2025-2026");
      setSeuilRetard(String((s.seuil_retard_minutes as number) ?? 15));
      setLoading(false);
    });
  }, []);

  const canEdit = profile ? can(profile.role, "parametres", "modifier") : false;

  const save = async () => {
    if (!profile) return;
    setSaving(true);
    await Promise.all([
      setSetting("nom_ecole", nomEcole, profile.id),
      setSetting("annee_scolaire_active", anneeActive, profile.id),
      setSetting("seuil_retard_minutes", Number(seuilRetard), profile.id),
    ]);
    setSaving(false);
    setSaved(true);
    setTimeout(() => setSaved(false), 2500);
  };

  if (loading) {
    return (
      <DashboardShell title="Paramètres">
        <p className="text-sm text-muted-foreground">Chargement…</p>
      </DashboardShell>
    );
  }

  if (!canEdit) {
    return (
      <DashboardShell title="Paramètres">
        <p className="text-sm text-muted-foreground">
          Seuls les comptes Administration et Direction peuvent modifier les paramètres de l'école.
        </p>
      </DashboardShell>
    );
  }

  return (
    <DashboardShell title="Paramètres">
      <Card className="max-w-xl">
        <CardHeader><CardTitle>Informations générales</CardTitle></CardHeader>
        <CardContent className="space-y-4">
          <div>
            <label className="text-sm font-medium mb-1.5 block">Nom de l'établissement</label>
            <input className="input" value={nomEcole} onChange={(e) => setNomEcole(e.target.value)} />
          </div>
          <div>
            <label className="text-sm font-medium mb-1.5 block">Année scolaire active</label>
            <input className="input" placeholder="2025-2026" value={anneeActive} onChange={(e) => setAnneeActive(e.target.value)} />
          </div>
          <div>
            <label className="text-sm font-medium mb-1.5 block">Seuil de retard (minutes)</label>
            <input type="number" className="input" value={seuilRetard} onChange={(e) => setSeuilRetard(e.target.value)} />
            <p className="text-xs text-muted-foreground mt-1">
              Au-delà de ce délai après le début du cours, une présence est marquée « retard ».
            </p>
          </div>
          <div className="flex items-center gap-3 pt-2">
            <Button onClick={save} disabled={saving}>{saving ? "Enregistrement…" : "Enregistrer"}</Button>
            {saved && <span className="text-sm text-emerald-600">Enregistré ✓</span>}
          </div>
        </CardContent>
      </Card>
    </DashboardShell>
  );
}
