"use client";

import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useRouter } from "next/navigation";
import { GraduationCap, Lock } from "lucide-react";
import { Button } from "@/components/ui/button";
import { updatePassword } from "@/lib/auth/auth-service";

const schema = z
  .object({
    password: z.string().min(6, "6 caractères minimum"),
    confirmPassword: z.string().min(6, "6 caractères minimum"),
  })
  .refine((data) => data.password === data.confirmPassword, {
    message: "Les mots de passe ne correspondent pas",
    path: ["confirmPassword"],
  });
type FormValues = z.infer<typeof schema>;

export default function UpdatePasswordPage() {
  const router = useRouter();
  const [serverError, setServerError] = useState<string | null>(null);
  const {
    register,
    handleSubmit,
    formState: { errors, isSubmitting },
  } = useForm<FormValues>({ resolver: zodResolver(schema) });

  const onSubmit = async (data: FormValues) => {
    setServerError(null);
    const result = await updatePassword(data.password);
    if (!result.success) {
      setServerError(result.error ?? "Une erreur est survenue.");
      return;
    }
    router.push("/dashboard");
    router.refresh();
  };

  return (
    <div className="min-h-screen grid lg:grid-cols-2">
      <div className="hidden lg:flex flex-col justify-between premium-gradient p-10 text-white">
        <div className="flex items-center gap-2">
          <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-primary">
            <GraduationCap className="h-5 w-5" />
          </div>
          <span className="font-semibold">PRO TECHNICA ÉCOLE</span>
        </div>
        <div>
          <h2 className="text-3xl font-semibold leading-tight mb-3">
            Choisissez un nouveau<br />mot de passe.
          </h2>
          <p className="text-white/60 max-w-md">
            Optez pour un mot de passe robuste, que vous n&apos;utilisez sur aucun autre service.
          </p>
        </div>
        <p className="text-xs text-white/40">© 2026 PRO TECHNICA ÉCOLE</p>
      </div>

      <div className="flex items-center justify-center p-6">
        <div className="w-full max-w-sm">
          <div className="lg:hidden flex items-center gap-2 mb-8">
            <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-primary">
              <GraduationCap className="h-5 w-5 text-white" />
            </div>
            <span className="font-semibold">PRO TECHNICA ÉCOLE</span>
          </div>

          <h1 className="text-2xl font-semibold mb-1">Nouveau mot de passe</h1>
          <p className="text-sm text-muted-foreground mb-6">Choisissez votre nouveau mot de passe.</p>

          <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
            <div>
              <label className="text-sm font-medium mb-1.5 block">Nouveau mot de passe</label>
              <div className="flex items-center gap-2 rounded-lg border border-border bg-background px-3 py-2.5 focus-within:ring-2 focus-within:ring-ring">
                <Lock className="h-4 w-4 text-muted-foreground" />
                <input type="password" placeholder="••••••••" className="w-full bg-transparent text-sm outline-none" {...register("password")} />
              </div>
              {errors.password && <p className="text-xs text-red-600 mt-1">{errors.password.message}</p>}
            </div>

            <div>
              <label className="text-sm font-medium mb-1.5 block">Confirmer le mot de passe</label>
              <div className="flex items-center gap-2 rounded-lg border border-border bg-background px-3 py-2.5 focus-within:ring-2 focus-within:ring-ring">
                <Lock className="h-4 w-4 text-muted-foreground" />
                <input type="password" placeholder="••••••••" className="w-full bg-transparent text-sm outline-none" {...register("confirmPassword")} />
              </div>
              {errors.confirmPassword && <p className="text-xs text-red-600 mt-1">{errors.confirmPassword.message}</p>}
            </div>

            {serverError && (
              <p className="text-sm text-red-600 bg-red-50 border border-red-200 rounded-lg px-3 py-2">{serverError}</p>
            )}

            <Button type="submit" className="w-full" size="lg" disabled={isSubmitting}>
              {isSubmitting ? "Mise à jour…" : "Mettre à jour le mot de passe"}
            </Button>
          </form>
        </div>
      </div>
    </div>
  );
}
