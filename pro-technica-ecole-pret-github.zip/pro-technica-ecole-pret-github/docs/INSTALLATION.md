# Installation — PRO TECHNICA ÉCOLE

## 1. Prérequis

- Node.js ≥ 18.18
- Un projet Supabase (déjà créé et configuré : `aydvajqnxspeaiolzite` / région eu-west-1)
- Le CLI Supabase (optionnel, pour régénérer les types ou rejouer les migrations en local) : `npm i -g supabase`

## 2. Installation des dépendances

```bash
npm install
```

Ceci installe notamment les deux nouveaux paquets ajoutés en Phase 2 :
`@supabase/supabase-js` et `@supabase/ssr`.

## 3. Variables d'environnement

```bash
cp .env.example .env.local
```

Le fichier `.env.example` contient déjà l'URL et la clé publique (`anon`) du
projet Supabase de PRO TECHNICA ÉCOLE. Il ne manque que
`SUPABASE_SERVICE_ROLE_KEY` si vous avez besoin d'exécuter des scripts
d'administration côté serveur (import en masse, tâches cron) — à récupérer
dans **Project Settings → API → service_role** sur le dashboard Supabase.
**Ne jamais committer cette clé.**

## 4. Base de données

Le schéma complet (26 tables, RLS, triggers, storage, realtime) est **déjà
déployé** sur le projet Supabase `aydvajqnxspeaiolzite`. Les 14 migrations
SQL sont versionnées dans `supabase/migrations/` pour :

- traçabilité et revue de code,
- réplication sur un environnement de test/staging séparé,
- reconstruction complète en cas de nouveau projet Supabase.

Pour rejouer les migrations sur un **nouveau** projet Supabase (staging, par ex.) :

```bash
supabase link --project-ref <votre-project-ref>
supabase db push
```

## 5. Premier compte administrateur

Aucun compte n'existe encore. Pour créer le premier administrateur :

1. Dans le dashboard Supabase → **Authentication → Users → Add user**,
   créez un utilisateur avec un email et un mot de passe.
2. Dans **Table Editor → profiles**, retrouvez la ligne créée automatiquement
   (trigger `handle_new_user`) et changez `role` de `etudiant` à `administrateur`.
3. Connectez-vous sur `/login` avec cet email/mot de passe.

Une fois connecté comme administrateur, tous les autres comptes (direction,
comptable, professeurs, étudiants, parents) peuvent être créés depuis
l'interface (Authentication → Invite user, ou `signUp()` avec le rôle voulu
dans `lib/auth/auth-service.ts`) : le profil et son rôle sont attribués
automatiquement par le trigger `handle_new_user`.

## 6. Lancer en développement

```bash
npm run dev
```

L'application est disponible sur `http://localhost:3000`, redirige vers
`/login`, puis vers `/dashboard` une fois connecté.

## 7. Régénérer les types TypeScript (si le schéma évolue)

```bash
supabase gen types typescript --project-id aydvajqnxspeaiolzite > lib/supabase/database.types.ts
```

## 8. Données de démonstration

`lib/mock-data.ts` est conservé tel quel (non utilisé par l'application, qui
lit désormais Supabase) : il sert de **référence de forme des données** et
peut inspirer un script de seed pour peupler un environnement de démo/staging.
