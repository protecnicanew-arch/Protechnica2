import { createClient } from "@/lib/supabase/client";
import type { Grade } from "@/lib/types";

const GRADE_SELECT = `
  id, note, student_id, saisi_par,
  exam:exams ( id, titre, type, date, bareme, coefficient, subject:subjects ( nom ), teacher_id )
`;

// eslint-disable-next-line @typescript-eslint/no-explicit-any
function mapGrade(row: any): Grade {
  return {
    id: row.id,
    studentId: row.student_id,
    matiere: row.exam?.subject?.nom ?? "",
    type: row.exam?.type ?? "controle",
    note: Number(row.note),
    bareme: Number(row.exam?.bareme ?? 20),
    coefficient: Number(row.exam?.coefficient ?? 1),
    date: row.exam?.date ?? "",
    professeurId: row.exam?.teacher_id ?? row.saisi_par ?? "",
  };
}

export async function listGradesForStudent(studentId: string): Promise<Grade[]> {
  const supabase = createClient();
  const { data, error } = await supabase.from("grades").select(GRADE_SELECT).eq("student_id", studentId);
  if (error) throw error;
  return (data ?? []).map(mapGrade);
}

export async function listGradesForClasse(classeId: string, periode?: string): Promise<Grade[]> {
  const supabase = createClient();
  let query = supabase
    .from("grades")
    .select(`${GRADE_SELECT}, exam:exams!inner ( classe_id, periode )`);
  query = query.eq("exam.classe_id", classeId);
  if (periode) query = query.eq("exam.periode", periode);
  const { data, error } = await query;
  if (error) throw error;
  return (data ?? []).map(mapGrade);
}

/** Trimestre francophone déduit de la date (Sept-Déc T1, Jan-Mar T2, Avr-Août T3). */
function periodeFromDate(dateIso: string): string {
  const month = new Date(dateIso).getMonth() + 1; // 1-12
  if (month >= 9 && month <= 12) return "Trimestre 1";
  if (month >= 1 && month <= 3) return "Trimestre 2";
  return "Trimestre 3";
}

/**
 * Crée l'examen s'il n'existe pas déjà pour (classe, matière, type, date, période),
 * puis upsert la note de l'étudiant — reproduit le upsertGrade() de l'ancien store.
 * Prend directement le nom de la matière et l'id du professeur, comme le
 * faisait l'ancien store Zustand basé sur les mocks (résolution automatique
 * de la classe de l'étudiant et de l'id de la matière en base).
 */
export async function upsertGrade(params: {
  studentId: string;
  matiere: string;
  type: "controle" | "devoir" | "examen";
  note: number;
  bareme?: number;
  coefficient?: number;
  date: string;
  professeurId: string;
}): Promise<void> {
  const supabase = createClient();

  const { data: student, error: studentError } = await supabase
    .from("students")
    .select("classe_id")
    .eq("id", params.studentId)
    .single();
  if (studentError || !student?.classe_id) throw studentError ?? new Error("Étudiant sans classe assignée.");

  let { data: subject } = await supabase.from("subjects").select("id").eq("nom", params.matiere).maybeSingle();
  if (!subject) {
    const { data: created, error: subjectError } = await supabase
      .from("subjects")
      .insert({ nom: params.matiere })
      .select("id")
      .single();
    if (subjectError) throw subjectError;
    subject = created;
  }

  const classeId = student.classe_id;
  const subjectId = subject.id;
  const periode = periodeFromDate(params.date);

  const { data: existingExam } = await supabase
    .from("exams")
    .select("id")
    .eq("classe_id", classeId)
    .eq("subject_id", subjectId)
    .eq("type", params.type)
    .eq("date", params.date)
    .maybeSingle();

  let examId: string;
  if (existingExam) {
    examId = existingExam.id;
  } else {
    const { data: created, error: createError } = await supabase
      .from("exams")
      .insert({
        classe_id: classeId,
        subject_id: subjectId,
        teacher_id: params.professeurId,
        type: params.type,
        titre: `${params.type} — ${params.date}`,
        periode,
        bareme: params.bareme ?? 20,
        coefficient: params.coefficient ?? 1,
        date: params.date,
      })
      .select("id")
      .single();
    if (createError) throw createError;
    examId = created.id;
  }

  const { error } = await supabase.from("grades").upsert(
    { exam_id: examId, student_id: params.studentId, note: params.note, saisi_par: params.professeurId },
    { onConflict: "exam_id,student_id" }
  );
  if (error) throw error;
}

export async function deleteGrade(id: string) {
  const supabase = createClient();
  const { error } = await supabase.from("grades").delete().eq("id", id);
  if (error) throw error;
}

/** Calcule la moyenne pondérée (par coefficient) d'un étudiant sur une période et génère/actualise le bulletin. */
export async function generateReportCard(studentId: string, periode: string, classeId: string) {
  const supabase = createClient();
  const grades = await listGradesForClasse(classeId, periode);
  const studentGrades = grades.filter((g) => g.studentId === studentId);

  const totalCoef = studentGrades.reduce((sum, g) => sum + g.coefficient, 0);
  const moyenne = totalCoef > 0
    ? studentGrades.reduce((sum, g) => sum + (g.note / g.bareme) * 20 * g.coefficient, 0) / totalCoef
    : 0;

  // Classement au sein de la classe pour la période
  const byStudent = new Map<string, number>();
  for (const g of grades) {
    byStudent.set(g.studentId, (byStudent.get(g.studentId) ?? 0) + (g.note / g.bareme) * 20);
  }
  const sorted = [...byStudent.entries()].sort((a, b) => b[1] - a[1]);
  const rang = sorted.findIndex(([id]) => id === studentId) + 1;

  const { error } = await supabase.from("report_cards").upsert(
    {
      student_id: studentId,
      periode,
      moyenne_generale: Number(moyenne.toFixed(2)),
      rang: rang || null,
      effectif_classe: sorted.length,
    },
    { onConflict: "student_id,periode" }
  );
  if (error) throw error;
}

/** Génère (ou régénère) le bulletin de chaque étudiant d'une classe pour une période donnée. */
export async function generateReportCardsForClasse(classeId: string, periode: string, studentIds: string[]) {
  for (const studentId of studentIds) {
    await generateReportCard(studentId, periode, classeId);
  }
}

export interface ReportCardRow {
  studentId: string;
  periode: string;
  moyenneGenerale: number | null;
  rang: number | null;
  effectifClasse: number | null;
}

/** Liste les bulletins déjà générés pour un ensemble d'étudiants sur une période. */
export async function listReportCards(studentIds: string[], periode: string): Promise<ReportCardRow[]> {
  if (studentIds.length === 0) return [];
  const supabase = createClient();
  const { data, error } = await supabase
    .from("report_cards")
    .select("student_id, periode, moyenne_generale, rang, effectif_classe")
    .in("student_id", studentIds)
    .eq("periode", periode);
  if (error) throw error;
  return (data ?? []).map((r) => ({
    studentId: r.student_id,
    periode: r.periode,
    moyenneGenerale: r.moyenne_generale === null ? null : Number(r.moyenne_generale),
    rang: r.rang,
    effectifClasse: r.effectif_classe,
  }));
}
