import { createClient } from "@/lib/supabase/client";
import { markAttendance } from "./attendance.service";

/**
 * Génère (ou régénère) le QR code d'un étudiant : un identifiant opaque et
 * unique (jamais le matricule ni l'UUID brut, pour éviter toute devinabilité)
 * stocké à la fois sur `students.qr_code` et dans `student_cards` (historique
 * des cartes émises, avec date d'expiration).
 */
export async function issueStudentCard(studentId: string, expiresInDays = 365): Promise<string> {
  const supabase = createClient();
  const qrCode = `PT-${studentId.slice(0, 8)}-${crypto.randomUUID().slice(0, 12)}`;
  const dateExpiration = new Date(Date.now() + expiresInDays * 86_400_000).toISOString().slice(0, 10);

  const { error: e1 } = await supabase.from("students").update({ qr_code: qrCode }).eq("id", studentId);
  if (e1) throw e1;

  const { error: e2 } = await supabase
    .from("student_cards")
    .insert({ student_id: studentId, qr_code: qrCode, date_expiration: dateExpiration });
  if (e2) throw e2;

  return qrCode;
}

/**
 * Scan d'une carte étudiant : résout le QR code vers l'étudiant, puis pointe
 * sa présence pour la classe/date du jour. Utilisé par la page de scan de
 * présence (StudentQRCards / scanner mobile).
 */
export async function checkInByQrCode(qrCode: string, classeId: string): Promise<{ studentId: string; fullName: string }> {
  const supabase = createClient();
  const { data: student, error } = await supabase
    .from("students")
    .select("id, classe_id, profile:profiles!students_id_fkey(full_name)")
    .eq("qr_code", qrCode)
    .single();
  if (error || !student) throw new Error("Carte QR invalide ou introuvable.");

  await markAttendance({
    personId: student.id,
    personType: "etudiant",
    date: new Date().toISOString().slice(0, 10),
    status: "present",
    classeId,
  });

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  return { studentId: student.id, fullName: (student.profile as any)?.full_name ?? "" };
}
