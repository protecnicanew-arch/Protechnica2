import { createClient } from "@/lib/supabase/client";
import type { Attendance, AttendanceStatus } from "@/lib/types";

/**
 * Marque (ou remplace) la présence d'une personne pour une classe/date donnée.
 * Crée la session (`attendance`) si elle n'existe pas encore, puis upsert le
 * détail (`attendance_details`) — reproduit le comportement idempotent de
 * l'ancien store Zustand (une entrée par personne/date).
 */
export async function markAttendance(params: {
  personId: string;
  personType: "etudiant" | "professeur";
  date: string;
  status: AttendanceStatus;
  classeId?: string;
  subjectId?: string;
  teacherId?: string;
}): Promise<void> {
  const supabase = createClient();

  let attendanceId: string;
  const { data: existingSession } = await supabase
    .from("attendance")
    .select("id")
    .eq("date", params.date)
    .eq("classe_id", params.classeId ?? "")
    .maybeSingle();

  if (existingSession) {
    attendanceId = existingSession.id;
  } else {
    const { data: created, error: createError } = await supabase
      .from("attendance")
      .insert({ classe_id: params.classeId, subject_id: params.subjectId, teacher_id: params.teacherId, date: params.date })
      .select("id")
      .single();
    if (createError) throw createError;
    attendanceId = created.id;
  }

  const { error } = await supabase.from("attendance_details").upsert(
    {
      attendance_id: attendanceId,
      person_id: params.personId,
      person_type: params.personType,
      status: params.status,
    },
    { onConflict: "attendance_id,person_id" }
  );
  if (error) throw error;
}

export async function listAttendanceForClasse(classeId: string, date: string): Promise<Attendance[]> {
  const supabase = createClient();
  const { data, error } = await supabase
    .from("attendance")
    .select("id, date, classe_id, attendance_details ( id, person_id, person_type, status )")
    .eq("classe_id", classeId)
    .eq("date", date);
  if (error) throw error;

  return (data ?? []).flatMap((session) =>
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    (session.attendance_details as any[]).map((d) => ({
      id: d.id,
      personId: d.person_id,
      personType: d.person_type,
      date: session.date,
      status: d.status,
      classeId: session.classe_id ?? undefined,
    }))
  );
}

/** Taux de présence moyen sur une période, pour le tableau de bord. */
export async function getAverageAttendanceRate(sinceDate: string): Promise<number> {
  const supabase = createClient();
  const { data, error } = await supabase
    .from("attendance_details")
    .select("status, attendance:attendance!inner(date)")
    .gte("attendance.date", sinceDate);
  if (error || !data || data.length === 0) return 0;
  const present = data.filter((d) => d.status === "present" || d.status === "retard").length;
  return Math.round((present / data.length) * 100);
}
