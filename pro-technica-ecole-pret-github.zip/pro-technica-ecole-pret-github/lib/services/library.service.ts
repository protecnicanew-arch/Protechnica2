import { createClient } from "@/lib/supabase/client";

export interface LibraryResource {
  id: string;
  titre: string;
  auteur?: string;
  categorie?: string;
  fichierUrl?: string;
  disponible: boolean;
}

function mapResource(row: {
  id: string; titre: string; auteur: string | null; categorie: string | null;
  fichier_url: string | null; disponible: boolean;
}): LibraryResource {
  return {
    id: row.id, titre: row.titre, auteur: row.auteur ?? undefined, categorie: row.categorie ?? undefined,
    fichierUrl: row.fichier_url ?? undefined, disponible: row.disponible,
  };
}

export async function listResources(): Promise<LibraryResource[]> {
  const supabase = createClient();
  const { data, error } = await supabase.from("library_resources").select("*").order("titre");
  if (error) throw error;
  return (data ?? []).map(mapResource);
}

export async function createResource(params: {
  titre: string; auteur?: string; categorie?: string; fichierUrl?: string;
}) {
  const supabase = createClient();
  const { error } = await supabase.from("library_resources").insert({
    titre: params.titre, auteur: params.auteur, categorie: params.categorie, fichier_url: params.fichierUrl,
  });
  if (error) throw error;
}

export async function toggleDisponibilite(id: string, disponible: boolean) {
  const supabase = createClient();
  const { error } = await supabase.from("library_resources").update({ disponible }).eq("id", id);
  if (error) throw error;
}

export async function deleteResource(id: string) {
  const supabase = createClient();
  const { error } = await supabase.from("library_resources").delete().eq("id", id);
  if (error) throw error;
}
