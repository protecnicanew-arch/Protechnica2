import { createClient } from "@/lib/supabase/client";
import type { Payment } from "@/lib/types";

function mapPayment(row: {
  id: string; student_id: string; libelle: string; montant_du: number;
  status: Payment["status"]; date_echeance: string | null; created_at: string;
}, montantPaye: number): Payment {
  return {
    id: row.id,
    studentId: row.student_id,
    libelle: row.libelle,
    montantDu: Number(row.montant_du),
    montantPaye,
    date: row.date_echeance ?? row.created_at,
    status: row.status,
  };
}

export async function listPaymentsForStudent(studentId: string): Promise<Payment[]> {
  const supabase = createClient();
  const { data, error } = await supabase
    .from("payments")
    .select("*, payment_installments ( montant, recu_url )")
    .eq("student_id", studentId)
    .order("created_at", { ascending: false });
  if (error) throw error;

  return (data ?? []).map((row) => {
    const montantPaye = (row.payment_installments ?? []).reduce(
      (sum: number, i: { montant: number }) => sum + Number(i.montant),
      0
    );
    return mapPayment(row, montantPaye);
  });
}

export async function createPayment(params: {
  studentId: string;
  libelle: string;
  type: "inscription" | "scolarite" | "examen" | "autre";
  montantDu: number;
  dateEcheance?: string;
}) {
  const supabase = createClient();
  const { error } = await supabase.from("payments").insert({
    student_id: params.studentId,
    libelle: params.libelle,
    type: params.type,
    montant_du: params.montantDu,
    date_echeance: params.dateEcheance,
  });
  if (error) throw error;
}

/**
 * Enregistre un versement. Le trigger `recompute_payment_status` recalcule
 * automatiquement le statut du paiement et le solde restant de l'étudiant.
 * Le numéro de reçu est généré côté client (séquence lisible) puis stocké.
 */
export async function recordInstallment(params: {
  paymentId: string;
  montant: number;
  modePaiement: "especes" | "virement" | "mobile_money" | "cheque" | "carte";
  encaissePar: string;
}): Promise<{ installmentId: string; recuNumero: string }> {
  const supabase = createClient();
  const recuNumero = `REC-${Date.now().toString(36).toUpperCase()}`;

  const { data, error } = await supabase
    .from("payment_installments")
    .insert({
      payment_id: params.paymentId,
      montant: params.montant,
      mode_paiement: params.modePaiement,
      encaisse_par: params.encaissePar,
      recu_numero: recuNumero,
    })
    .select("id")
    .single();
  if (error) throw error;

  return { installmentId: data.id, recuNumero };
}

/** Associe l'URL du reçu PDF (généré et uploadé côté client) à un versement. */
export async function attachReceiptUrl(installmentId: string, recuUrl: string) {
  const supabase = createClient();
  const { error } = await supabase.from("payment_installments").update({ recu_url: recuUrl }).eq("id", installmentId);
  if (error) throw error;
}

/** Tous les paiements, tous étudiants confondus — vue globale (admin/comptable). */
export async function listAllPayments(): Promise<Payment[]> {
  const supabase = createClient();
  const { data, error } = await supabase
    .from("payments")
    .select("*, payment_installments ( montant )")
    .order("created_at", { ascending: false })
    .limit(200);
  if (error) throw error;
  return (data ?? []).map((row) => {
    const montantPaye = (row.payment_installments ?? []).reduce(
      (sum: number, i: { montant: number }) => sum + Number(i.montant),
      0
    );
    return mapPayment(row, montantPaye);
  });
}

export async function listUnpaidStudentsCount(): Promise<number> {
  const supabase = createClient();
  const { count, error } = await supabase
    .from("students")
    .select("id", { count: "exact", head: true })
    .gt("solde_restant", 0);
  if (error) throw error;
  return count ?? 0;
}

export async function getMonthlyRevenue(monthStartIso: string): Promise<number> {
  const supabase = createClient();
  const { data, error } = await supabase
    .from("payment_installments")
    .select("montant")
    .gte("date_paiement", monthStartIso);
  if (error) throw error;
  return (data ?? []).reduce((sum, r) => sum + Number(r.montant), 0);
}
