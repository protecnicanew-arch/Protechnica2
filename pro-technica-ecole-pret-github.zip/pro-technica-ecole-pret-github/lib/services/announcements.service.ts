import { createClient } from "@/lib/supabase/client";
import type { Actualite } from "@/lib/types";
import type { UserRole } from "@/lib/auth/permissions";

function mapActualite(row: {
  id: string; titre: string; contenu: string; auteur_id: string | null;
  type: Actualite["type"]; image_url: string | null; date: string;
}): Actualite {
  return {
    id: row.id, titre: row.titre, contenu: row.contenu, auteurId: row.auteur_id ?? "",
    date: row.date, type: row.type, imageUrl: row.image_url ?? undefined,
  };
}

export async function listAnnouncements(): Promise<Actualite[]> {
  const supabase = createClient();
  const { data, error } = await supabase.from("announcements").select("*").order("date", { ascending: false });
  if (error) throw error;
  return (data ?? []).map(mapActualite);
}

export async function createAnnouncement(params: {
  titre: string; contenu: string; auteurId: string; type: Actualite["type"];
  imageUrl?: string; cibleRoles?: UserRole[];
}) {
  const supabase = createClient();
  const { error } = await supabase.from("announcements").insert({
    titre: params.titre, contenu: params.contenu, auteur_id: params.auteurId,
    type: params.type, image_url: params.imageUrl, cible_roles: params.cibleRoles,
  });
  if (error) throw error;
}

export async function deleteAnnouncement(id: string) {
  const supabase = createClient();
  const { error } = await supabase.from("announcements").delete().eq("id", id);
  if (error) throw error;
}
