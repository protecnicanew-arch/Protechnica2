import { createClient } from "@/lib/supabase/client";
import type { Teacher } from "@/lib/types";

const TEACHER_SELECT = `
  id, matricule, photo_url, date_embauche,
  profile:profiles!teachers_id_fkey ( full_name, email, phone ),
  teacher_subjects ( subject:subjects ( nom ) ),
  teacher_classes ( classe_id )
`;

// eslint-disable-next-line @typescript-eslint/no-explicit-any
function mapTeacher(row: any): Teacher {
  return {
    id: row.id,
    fullName: row.profile?.full_name ?? "",
    email: row.profile?.email ?? "",
    phone: row.profile?.phone ?? "",
    photoUrl: row.photo_url ?? undefined,
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    matieres: (row.teacher_subjects ?? []).map((ts: any) => ts.subject?.nom).filter(Boolean),
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    classesIds: (row.teacher_classes ?? []).map((tc: any) => tc.classe_id),
    dateEmbauche: row.date_embauche,
  };
}

export async function listTeachers(): Promise<Teacher[]> {
  const supabase = createClient();
  const { data, error } = await supabase.from("teachers").select(TEACHER_SELECT).order("created_at");
  if (error) throw error;
  return (data ?? []).map(mapTeacher);
}

export async function getTeacher(id: string): Promise<Teacher | null> {
  const supabase = createClient();
  const { data, error } = await supabase.from("teachers").select(TEACHER_SELECT).eq("id", id).single();
  if (error) return null;
  return mapTeacher(data);
}

export async function assignTeacherToClasse(teacherId: string, classeId: string) {
  const supabase = createClient();
  const { error } = await supabase.from("teacher_classes").insert({ teacher_id: teacherId, classe_id: classeId });
  if (error) throw error;
}

export async function assignTeacherToSubject(teacherId: string, subjectId: string) {
  const supabase = createClient();
  const { error } = await supabase
    .from("teacher_subjects")
    .insert({ teacher_id: teacherId, subject_id: subjectId });
  if (error) throw error;
}

export async function setPrincipalTeacher(classeId: string, teacherId: string | undefined) {
  const supabase = createClient();
  const { error } = await supabase
    .from("classes")
    .update({ professeur_principal_id: teacherId ?? null })
    .eq("id", classeId);
  if (error) throw error;
}
