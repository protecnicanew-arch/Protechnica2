// ============================================================
// Types générés automatiquement depuis le schéma Supabase.
// Ne pas éditer à la main — régénérer avec :
//   supabase gen types typescript --project-id aydvajqnxspeaiolzite > lib/supabase/database.types.ts
// ============================================================
export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  __InternalSupabase: {
    PostgrestVersion: "14.5"
  }
  public: {
    Tables: {
      announcements: {
        Row: {
          auteur_id: string | null
          cible_roles: Database["public"]["Enums"]["user_role"][] | null
          contenu: string
          created_at: string
          date: string
          id: string
          image_url: string | null
          titre: string
          type: Database["public"]["Enums"]["announcement_type"]
        }
        Insert: {
          auteur_id?: string | null
          cible_roles?: Database["public"]["Enums"]["user_role"][] | null
          contenu: string
          created_at?: string
          date?: string
          id?: string
          image_url?: string | null
          titre: string
          type?: Database["public"]["Enums"]["announcement_type"]
        }
        Relationships: [
          {
            foreignKeyName: "announcements_auteur_id_fkey"
            columns: ["auteur_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          }
        ]
        Update: Partial<Database["public"]["Tables"]["announcements"]["Insert"]>
      }
      attendance: {
        Row: {
          classe_id: string | null
          created_at: string
          created_by: string | null
          date: string
          id: string
          subject_id: string | null
          teacher_id: string | null
        }
        Insert: {
          classe_id?: string | null
          created_at?: string
          created_by?: string | null
          date?: string
          id?: string
          subject_id?: string | null
          teacher_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "attendance_classe_id_fkey"
            columns: ["classe_id"]
            isOneToOne: false
            referencedRelation: "classes"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "attendance_subject_id_fkey"
            columns: ["subject_id"]
            isOneToOne: false
            referencedRelation: "subjects"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "attendance_teacher_id_fkey"
            columns: ["teacher_id"]
            isOneToOne: false
            referencedRelation: "teachers"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "attendance_created_by_fkey"
            columns: ["created_by"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          }
        ]
        Update: Partial<Database["public"]["Tables"]["attendance"]["Insert"]>
      }
      attendance_details: {
        Row: {
          attendance_id: string
          created_at: string
          id: string
          justificatif_url: string | null
          person_id: string
          person_type: Database["public"]["Enums"]["person_type"]
          status: Database["public"]["Enums"]["attendance_status"]
        }
        Insert: {
          attendance_id: string
          created_at?: string
          id?: string
          justificatif_url?: string | null
          person_id: string
          person_type: Database["public"]["Enums"]["person_type"]
          status?: Database["public"]["Enums"]["attendance_status"]
        }
        Relationships: [
          {
            foreignKeyName: "attendance_details_attendance_id_fkey"
            columns: ["attendance_id"]
            isOneToOne: false
            referencedRelation: "attendance"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "attendance_details_person_id_fkey"
            columns: ["person_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          }
        ]
        Update: Partial<Database["public"]["Tables"]["attendance_details"]["Insert"]>
      }
      audit_logs: {
        Row: {
          action: Database["public"]["Enums"]["audit_action"]
          created_at: string
          details: Json | null
          id: string
          ip_address: string | null
          record_id: string | null
          table_name: string | null
          user_id: string | null
          user_name: string | null
        }
        Insert: {
          action: Database["public"]["Enums"]["audit_action"]
          created_at?: string
          details?: Json | null
          id?: string
          ip_address?: string | null
          record_id?: string | null
          table_name?: string | null
          user_id?: string | null
          user_name?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "audit_logs_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          }
        ]
        Update: Partial<Database["public"]["Tables"]["audit_logs"]["Insert"]>
      }
      classes: {
        Row: {
          annee_scolaire: string
          created_at: string
          effectif_max: number
          id: string
          nom: string
          professeur_principal_id: string | null
          program_id: string
        }
        Insert: {
          annee_scolaire: string
          created_at?: string
          effectif_max?: number
          id?: string
          nom: string
          professeur_principal_id?: string | null
          program_id: string
        }
        Relationships: [
          {
            foreignKeyName: "classes_program_id_fkey"
            columns: ["program_id"]
            isOneToOne: false
            referencedRelation: "programs"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "classes_professeur_principal_id_fkey"
            columns: ["professeur_principal_id"]
            isOneToOne: false
            referencedRelation: "teachers"
            referencedColumns: ["id"]
          }
        ]
        Update: Partial<Database["public"]["Tables"]["classes"]["Insert"]>
      }
      departments: {
        Row: { created_at: string; description: string | null; id: string; nom: string }
        Insert: { created_at?: string; description?: string | null; id?: string; nom: string }
        Relationships: []
        Update: Partial<Database["public"]["Tables"]["departments"]["Insert"]>
      }
      documents: {
        Row: {
          created_at: string
          id: string
          nom: string
          owner_id: string | null
          owner_type: Database["public"]["Enums"]["document_owner_type"]
          storage_path: string
          taille_octets: number | null
          type: string | null
          uploaded_by: string | null
        }
        Insert: {
          created_at?: string
          id?: string
          nom: string
          owner_id?: string | null
          owner_type?: Database["public"]["Enums"]["document_owner_type"]
          storage_path: string
          taille_octets?: number | null
          type?: string | null
          uploaded_by?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "documents_owner_id_fkey"
            columns: ["owner_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "documents_uploaded_by_fkey"
            columns: ["uploaded_by"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          }
        ]
        Update: Partial<Database["public"]["Tables"]["documents"]["Insert"]>
      }
      exams: {
        Row: {
          bareme: number
          classe_id: string
          coefficient: number
          created_at: string
          date: string
          id: string
          periode: string
          subject_id: string
          teacher_id: string | null
          titre: string
          type: Database["public"]["Enums"]["exam_type"]
        }
        Insert: {
          bareme?: number
          classe_id: string
          coefficient?: number
          created_at?: string
          date?: string
          id?: string
          periode: string
          subject_id: string
          teacher_id?: string | null
          titre: string
          type?: Database["public"]["Enums"]["exam_type"]
        }
        Relationships: [
          {
            foreignKeyName: "exams_classe_id_fkey"
            columns: ["classe_id"]
            isOneToOne: false
            referencedRelation: "classes"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "exams_subject_id_fkey"
            columns: ["subject_id"]
            isOneToOne: false
            referencedRelation: "subjects"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "exams_teacher_id_fkey"
            columns: ["teacher_id"]
            isOneToOne: false
            referencedRelation: "teachers"
            referencedColumns: ["id"]
          }
        ]
        Update: Partial<Database["public"]["Tables"]["exams"]["Insert"]>
      }
      expenses: {
        Row: {
          categorie: string
          created_at: string
          created_by: string | null
          date: string
          id: string
          justificatif_url: string | null
          libelle: string
          montant: number
        }
        Insert: {
          categorie: string
          created_at?: string
          created_by?: string | null
          date?: string
          id?: string
          justificatif_url?: string | null
          libelle: string
          montant: number
        }
        Relationships: [
          {
            foreignKeyName: "expenses_created_by_fkey"
            columns: ["created_by"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          }
        ]
        Update: Partial<Database["public"]["Tables"]["expenses"]["Insert"]>
      }
      grades: {
        Row: {
          commentaire: string | null
          created_at: string
          exam_id: string
          id: string
          note: number
          saisi_par: string | null
          student_id: string
          updated_at: string
        }
        Insert: {
          commentaire?: string | null
          created_at?: string
          exam_id: string
          id?: string
          note: number
          saisi_par?: string | null
          student_id: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "grades_exam_id_fkey"
            columns: ["exam_id"]
            isOneToOne: false
            referencedRelation: "exams"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "grades_student_id_fkey"
            columns: ["student_id"]
            isOneToOne: false
            referencedRelation: "students"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "grades_saisi_par_fkey"
            columns: ["saisi_par"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          }
        ]
        Update: Partial<Database["public"]["Tables"]["grades"]["Insert"]>
      }
      library_resources: {
        Row: {
          auteur: string | null
          categorie: string | null
          created_at: string
          disponible: boolean
          fichier_url: string | null
          id: string
          titre: string
        }
        Insert: {
          auteur?: string | null
          categorie?: string | null
          created_at?: string
          disponible?: boolean
          fichier_url?: string | null
          id?: string
          titre: string
        }
        Relationships: []
        Update: Partial<Database["public"]["Tables"]["library_resources"]["Insert"]>
      }
      notifications: {
        Row: {
          created_at: string
          id: string
          lien: string | null
          lu: boolean
          message: string
          titre: string
          type: string
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          lien?: string | null
          lu?: boolean
          message: string
          titre: string
          type?: string
          user_id: string
        }
        Relationships: [
          {
            foreignKeyName: "notifications_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          }
        ]
        Update: Partial<Database["public"]["Tables"]["notifications"]["Insert"]>
      }
      parents: {
        Row: { created_at: string; id: string; photo_url: string | null; profession: string | null }
        Insert: { created_at?: string; id: string; photo_url?: string | null; profession?: string | null }
        Relationships: [
          {
            foreignKeyName: "parents_id_fkey"
            columns: ["id"]
            isOneToOne: true
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          }
        ]
        Update: Partial<Database["public"]["Tables"]["parents"]["Insert"]>
      }
      payment_installments: {
        Row: {
          created_at: string
          date_paiement: string
          encaisse_par: string | null
          id: string
          mode_paiement: Database["public"]["Enums"]["payment_mode"]
          montant: number
          payment_id: string
          recu_numero: string | null
          recu_url: string | null
        }
        Insert: {
          created_at?: string
          date_paiement?: string
          encaisse_par?: string | null
          id?: string
          mode_paiement?: Database["public"]["Enums"]["payment_mode"]
          montant: number
          payment_id: string
          recu_numero?: string | null
          recu_url?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "payment_installments_payment_id_fkey"
            columns: ["payment_id"]
            isOneToOne: false
            referencedRelation: "payments"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "payment_installments_encaisse_par_fkey"
            columns: ["encaisse_par"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          }
        ]
        Update: Partial<Database["public"]["Tables"]["payment_installments"]["Insert"]>
      }
      payments: {
        Row: {
          created_at: string
          created_by: string | null
          date_echeance: string | null
          id: string
          libelle: string
          montant_du: number
          status: Database["public"]["Enums"]["payment_status"]
          student_id: string
          type: Database["public"]["Enums"]["payment_type"]
          updated_at: string
        }
        Insert: {
          created_at?: string
          created_by?: string | null
          date_echeance?: string | null
          id?: string
          libelle: string
          montant_du: number
          status?: Database["public"]["Enums"]["payment_status"]
          student_id: string
          type?: Database["public"]["Enums"]["payment_type"]
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "payments_student_id_fkey"
            columns: ["student_id"]
            isOneToOne: false
            referencedRelation: "students"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "payments_created_by_fkey"
            columns: ["created_by"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          }
        ]
        Update: Partial<Database["public"]["Tables"]["payments"]["Insert"]>
      }
      profiles: {
        Row: {
          avatar_url: string | null
          created_at: string
          email: string
          full_name: string
          id: string
          is_active: boolean
          phone: string | null
          role: Database["public"]["Enums"]["user_role"]
          updated_at: string
        }
        Insert: {
          avatar_url?: string | null
          created_at?: string
          email: string
          full_name: string
          id: string
          is_active?: boolean
          phone?: string | null
          role?: Database["public"]["Enums"]["user_role"]
          updated_at?: string
        }
        Relationships: []
        Update: Partial<Database["public"]["Tables"]["profiles"]["Insert"]>
      }
      programs: {
        Row: {
          created_at: string
          department_id: string | null
          description: string | null
          duree_annees: number
          id: string
          nom: string
          type: Database["public"]["Enums"]["program_type"]
        }
        Insert: {
          created_at?: string
          department_id?: string | null
          description?: string | null
          duree_annees?: number
          id?: string
          nom: string
          type: Database["public"]["Enums"]["program_type"]
        }
        Relationships: [
          {
            foreignKeyName: "programs_department_id_fkey"
            columns: ["department_id"]
            isOneToOne: false
            referencedRelation: "departments"
            referencedColumns: ["id"]
          }
        ]
        Update: Partial<Database["public"]["Tables"]["programs"]["Insert"]>
      }
      report_cards: {
        Row: {
          appreciation: string | null
          created_at: string
          effectif_classe: number | null
          genere_par: string | null
          id: string
          moyenne_generale: number | null
          pdf_url: string | null
          periode: string
          rang: number | null
          student_id: string
        }
        Insert: {
          appreciation?: string | null
          created_at?: string
          effectif_classe?: number | null
          genere_par?: string | null
          id?: string
          moyenne_generale?: number | null
          pdf_url?: string | null
          periode: string
          rang?: number | null
          student_id: string
        }
        Relationships: [
          {
            foreignKeyName: "report_cards_student_id_fkey"
            columns: ["student_id"]
            isOneToOne: false
            referencedRelation: "students"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "report_cards_genere_par_fkey"
            columns: ["genere_par"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          }
        ]
        Update: Partial<Database["public"]["Tables"]["report_cards"]["Insert"]>
      }
      schedules: {
        Row: {
          classe_id: string
          created_at: string
          heure_debut: string
          heure_fin: string
          id: string
          jour: Database["public"]["Enums"]["day_of_week"]
          salle: string | null
          subject_id: string
          teacher_id: string
        }
        Insert: {
          classe_id: string
          created_at?: string
          heure_debut: string
          heure_fin: string
          id?: string
          jour: Database["public"]["Enums"]["day_of_week"]
          salle?: string | null
          subject_id: string
          teacher_id: string
        }
        Relationships: [
          {
            foreignKeyName: "schedules_classe_id_fkey"
            columns: ["classe_id"]
            isOneToOne: false
            referencedRelation: "classes"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "schedules_subject_id_fkey"
            columns: ["subject_id"]
            isOneToOne: false
            referencedRelation: "subjects"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "schedules_teacher_id_fkey"
            columns: ["teacher_id"]
            isOneToOne: false
            referencedRelation: "teachers"
            referencedColumns: ["id"]
          }
        ]
        Update: Partial<Database["public"]["Tables"]["schedules"]["Insert"]>
      }
      school_settings: {
        Row: { cle: string; id: string; updated_at: string; updated_by: string | null; valeur: Json }
        Insert: { cle: string; id?: string; updated_at?: string; updated_by?: string | null; valeur: Json }
        Relationships: [
          {
            foreignKeyName: "school_settings_updated_by_fkey"
            columns: ["updated_by"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          }
        ]
        Update: Partial<Database["public"]["Tables"]["school_settings"]["Insert"]>
      }
      student_cards: {
        Row: {
          created_at: string
          date_emission: string
          date_expiration: string | null
          id: string
          qr_code: string
          statut: string
          student_id: string
        }
        Insert: {
          created_at?: string
          date_emission?: string
          date_expiration?: string | null
          id?: string
          qr_code: string
          statut?: string
          student_id: string
        }
        Relationships: [
          {
            foreignKeyName: "student_cards_student_id_fkey"
            columns: ["student_id"]
            isOneToOne: false
            referencedRelation: "students"
            referencedColumns: ["id"]
          }
        ]
        Update: Partial<Database["public"]["Tables"]["student_cards"]["Insert"]>
      }
      student_parents: {
        Row: { parent_id: string; relation: string | null; student_id: string }
        Insert: { parent_id: string; relation?: string | null; student_id: string }
        Relationships: [
          {
            foreignKeyName: "student_parents_student_id_fkey"
            columns: ["student_id"]
            isOneToOne: false
            referencedRelation: "students"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "student_parents_parent_id_fkey"
            columns: ["parent_id"]
            isOneToOne: false
            referencedRelation: "parents"
            referencedColumns: ["id"]
          }
        ]
        Update: Partial<Database["public"]["Tables"]["student_parents"]["Insert"]>
      }
      students: {
        Row: {
          classe_id: string | null
          created_at: string
          date_inscription: string
          date_naissance: string | null
          id: string
          matricule: string
          photo_url: string | null
          program_id: string | null
          qr_code: string | null
          solde_restant: number
          statut: Database["public"]["Enums"]["student_status"]
          updated_at: string
        }
        Insert: {
          classe_id?: string | null
          created_at?: string
          date_inscription?: string
          date_naissance?: string | null
          id: string
          matricule: string
          photo_url?: string | null
          program_id?: string | null
          qr_code?: string | null
          solde_restant?: number
          statut?: Database["public"]["Enums"]["student_status"]
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "students_id_fkey"
            columns: ["id"]
            isOneToOne: true
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "students_classe_id_fkey"
            columns: ["classe_id"]
            isOneToOne: false
            referencedRelation: "classes"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "students_program_id_fkey"
            columns: ["program_id"]
            isOneToOne: false
            referencedRelation: "programs"
            referencedColumns: ["id"]
          }
        ]
        Update: Partial<Database["public"]["Tables"]["students"]["Insert"]>
      }
      subjects: {
        Row: {
          code: string | null
          coefficient_defaut: number
          created_at: string
          department_id: string | null
          id: string
          nom: string
        }
        Insert: {
          code?: string | null
          coefficient_defaut?: number
          created_at?: string
          department_id?: string | null
          id?: string
          nom: string
        }
        Relationships: [
          {
            foreignKeyName: "subjects_department_id_fkey"
            columns: ["department_id"]
            isOneToOne: false
            referencedRelation: "departments"
            referencedColumns: ["id"]
          }
        ]
        Update: Partial<Database["public"]["Tables"]["subjects"]["Insert"]>
      }
      teacher_classes: {
        Row: { classe_id: string; teacher_id: string }
        Insert: { classe_id: string; teacher_id: string }
        Relationships: [
          {
            foreignKeyName: "teacher_classes_teacher_id_fkey"
            columns: ["teacher_id"]
            isOneToOne: false
            referencedRelation: "teachers"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "teacher_classes_classe_id_fkey"
            columns: ["classe_id"]
            isOneToOne: false
            referencedRelation: "classes"
            referencedColumns: ["id"]
          }
        ]
        Update: Partial<Database["public"]["Tables"]["teacher_classes"]["Insert"]>
      }
      teacher_subjects: {
        Row: { subject_id: string; teacher_id: string }
        Insert: { subject_id: string; teacher_id: string }
        Relationships: [
          {
            foreignKeyName: "teacher_subjects_teacher_id_fkey"
            columns: ["teacher_id"]
            isOneToOne: false
            referencedRelation: "teachers"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "teacher_subjects_subject_id_fkey"
            columns: ["subject_id"]
            isOneToOne: false
            referencedRelation: "subjects"
            referencedColumns: ["id"]
          }
        ]
        Update: Partial<Database["public"]["Tables"]["teacher_subjects"]["Insert"]>
      }
      teachers: {
        Row: {
          created_at: string
          date_embauche: string
          id: string
          is_active: boolean
          matricule: string
          photo_url: string | null
          specialite: string | null
        }
        Insert: {
          created_at?: string
          date_embauche?: string
          id: string
          is_active?: boolean
          matricule: string
          photo_url?: string | null
          specialite?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "teachers_id_fkey"
            columns: ["id"]
            isOneToOne: true
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          }
        ]
        Update: Partial<Database["public"]["Tables"]["teachers"]["Insert"]>
      }
    }
    Views: { [_ in never]: never }
    Functions: {
      current_role: { Args: Record<string, never>; Returns: Database["public"]["Enums"]["user_role"] }
      is_admin_or_direction: { Args: Record<string, never>; Returns: boolean }
      is_comptable_or_above: { Args: Record<string, never>; Returns: boolean }
      is_parent_of_student: { Args: { p_student_id: string }; Returns: boolean }
      is_teacher_of_classe: { Args: { p_classe_id: string }; Returns: boolean }
      is_teacher_of_student: { Args: { p_student_id: string }; Returns: boolean }
    }
    Enums: {
      announcement_type: "annonce" | "evenement" | "publication"
      attendance_status: "present" | "absent" | "retard" | "justifie"
      audit_action: "creation" | "modification" | "suppression" | "connexion" | "deconnexion" | "paiement"
      day_of_week: "Lundi" | "Mardi" | "Mercredi" | "Jeudi" | "Vendredi" | "Samedi"
      document_owner_type: "etudiant" | "professeur" | "classe" | "ecole"
      exam_type: "controle" | "devoir" | "examen"
      payment_mode: "especes" | "virement" | "mobile_money" | "cheque" | "carte"
      payment_status: "paye" | "partiel" | "impaye" | "en_retard"
      payment_type: "inscription" | "scolarite" | "examen" | "autre"
      person_type: "etudiant" | "professeur"
      program_type: "BTS" | "Licence" | "Master" | "Formation professionnelle"
      student_status: "actif" | "suspendu" | "diplome" | "abandon"
      user_role: "administrateur" | "direction" | "comptable" | "professeur" | "etudiant" | "parent"
    }
    CompositeTypes: { [_ in never]: never }
  }
}

export type Tables<T extends keyof Database["public"]["Tables"]> = Database["public"]["Tables"][T]["Row"]
export type TablesInsert<T extends keyof Database["public"]["Tables"]> = Database["public"]["Tables"][T]["Insert"]
export type TablesUpdate<T extends keyof Database["public"]["Tables"]> = Database["public"]["Tables"][T]["Update"]
export type Enums<T extends keyof Database["public"]["Enums"]> = Database["public"]["Enums"][T]
