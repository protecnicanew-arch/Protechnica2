import type { Enums } from "@/lib/supabase/database.types";

export type UserRole = Enums<"user_role">;

// Ressources fonctionnelles de l'application (correspond aux sections du menu)
export type Resource =
  | "etudiants"
  | "professeurs"
  | "classes"
  | "filieres"
  | "presences"
  | "notes"
  | "bulletins"
  | "paiements"
  | "comptabilite"
  | "bibliotheque"
  | "actualites"
  | "parametres"
  | "emploi_temps"
  | "audit";

export type Action = "voir" | "creer" | "modifier" | "supprimer";

// Matrice de permissions — reflète fidèlement les politiques RLS côté base
// de données. Cette table sert à adapter l'UI (masquer un bouton, une page),
// mais la sécurité réelle est TOUJOURS appliquée par PostgreSQL RLS.
const PERMISSIONS: Record<UserRole, Partial<Record<Resource, Action[]>>> = {
  administrateur: {
    etudiants: ["voir", "creer", "modifier", "supprimer"],
    professeurs: ["voir", "creer", "modifier", "supprimer"],
    classes: ["voir", "creer", "modifier", "supprimer"],
    filieres: ["voir", "creer", "modifier", "supprimer"],
    presences: ["voir", "creer", "modifier", "supprimer"],
    notes: ["voir", "creer", "modifier", "supprimer"],
    bulletins: ["voir", "creer", "modifier", "supprimer"],
    paiements: ["voir", "creer", "modifier", "supprimer"],
    comptabilite: ["voir", "creer", "modifier", "supprimer"],
    bibliotheque: ["voir", "creer", "modifier", "supprimer"],
    actualites: ["voir", "creer", "modifier", "supprimer"],
    parametres: ["voir", "creer", "modifier", "supprimer"],
    emploi_temps: ["voir", "creer", "modifier", "supprimer"],
    audit: ["voir"],
  },
  direction: {
    etudiants: ["voir", "creer", "modifier", "supprimer"],
    professeurs: ["voir", "creer", "modifier", "supprimer"],
    classes: ["voir", "creer", "modifier", "supprimer"],
    filieres: ["voir", "creer", "modifier", "supprimer"],
    presences: ["voir", "modifier"],
    notes: ["voir"],
    bulletins: ["voir", "creer"],
    paiements: ["voir", "creer", "modifier"],
    comptabilite: ["voir", "creer", "modifier"],
    bibliotheque: ["voir", "creer", "modifier"],
    actualites: ["voir", "creer", "modifier", "supprimer"],
    parametres: ["voir", "modifier"],
    emploi_temps: ["voir", "creer", "modifier"],
    audit: ["voir"],
  },
  comptable: {
    etudiants: ["voir"],
    paiements: ["voir", "creer", "modifier"],
    comptabilite: ["voir", "creer", "modifier"],
    actualites: ["voir"],
    bibliotheque: ["voir"],
  },
  professeur: {
    etudiants: ["voir"],
    classes: ["voir"],
    emploi_temps: ["voir"],
    presences: ["voir", "creer", "modifier"],
    notes: ["voir", "creer", "modifier"],
    bulletins: ["voir"],
    actualites: ["voir"],
    bibliotheque: ["voir"],
  },
  etudiant: {
    emploi_temps: ["voir"],
    notes: ["voir"],
    bulletins: ["voir"],
    presences: ["voir"],
    paiements: ["voir"],
    actualites: ["voir"],
    bibliotheque: ["voir"],
  },
  parent: {
    emploi_temps: ["voir"],
    notes: ["voir"],
    bulletins: ["voir"],
    presences: ["voir"],
    paiements: ["voir"],
    actualites: ["voir"],
    bibliotheque: ["voir"],
  },
};

export function can(role: UserRole, resource: Resource, action: Action): boolean {
  return PERMISSIONS[role]?.[resource]?.includes(action) ?? false;
}

export function canAny(role: UserRole, resource: Resource): boolean {
  return (PERMISSIONS[role]?.[resource]?.length ?? 0) > 0;
}

// Libellés d'affichage pour l'UI (badges, sélecteurs de rôle...)
export const ROLE_LABELS: Record<UserRole, string> = {
  administrateur: "Administrateur",
  direction: "Direction",
  comptable: "Comptable",
  professeur: "Professeur",
  etudiant: "Étudiant",
  parent: "Parent",
};
