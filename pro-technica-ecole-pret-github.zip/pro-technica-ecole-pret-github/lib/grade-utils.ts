import type { Grade, Student } from "./types";

export function computeAverage(grades: Grade[]): number | null {
  if (grades.length === 0) return null;
  const totalCoef = grades.reduce((sum, g) => sum + g.coefficient, 0);
  if (totalCoef === 0) return null;
  const weighted = grades.reduce((sum, g) => sum + (g.note / g.bareme) * 20 * g.coefficient, 0);
  return weighted / totalCoef;
}

export interface RankingRow {
  student: Student;
  moyenne: number | null;
  rang: number | null;
}

/** Classe les étudiants d'une classe par moyenne générale décroissante. */
export function computeClassRanking(students: Student[], grades: Grade[]): RankingRow[] {
  const rows = students.map((student) => ({
    student,
    moyenne: computeAverage(grades.filter((g) => g.studentId === student.id)),
  }));

  const withGrades = rows.filter((r) => r.moyenne !== null).sort((a, b) => (b.moyenne! - a.moyenne!));
  const withoutGrades = rows.filter((r) => r.moyenne === null);

  const ranked: RankingRow[] = withGrades.map((r, i) => ({ ...r, rang: i + 1 }));
  const unranked: RankingRow[] = withoutGrades.map((r) => ({ ...r, rang: null }));

  return [...ranked, ...unranked];
}
