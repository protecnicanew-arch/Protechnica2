// ============================================================
// PRO TECHNICA ÉCOLE — Façade de données RÉELLES (Supabase).
//
// Expose exactement la même surface de fonctions que l'ancien
// lib/mock-data.ts (mêmes noms, mêmes signatures), pour que les pages
// n'aient qu'à changer leur import ( "@/lib/mock-data" → "@/lib/data" )
// sans toucher au reste du code ni au design.
// ============================================================
import { useAcademicStore } from "./store";
import * as studentsService from "./services/students.service";
import * as teachersService from "./services/teachers.service";
import * as academicService from "./services/academic.service";
import * as paymentsService from "./services/payments.service";
import * as gradesService from "./services/grades.service";
import * as dashboardService from "./services/dashboard.service";
import * as announcementsService from "./services/announcements.service";
import * as schedulesService from "./services/schedules.service";

// ---- Tableau de bord ----
export const getDashboardStats = () => dashboardService.getDashboardStats();
export const getRevenueSeries = () => dashboardService.getRevenueSeries();
export const getEnrollmentByFiliere = () => dashboardService.getEnrollmentByFiliere();
export const getActivityLog = () => dashboardService.getRecentActivity();

// ---- Listes ----
export const getStudents = () => studentsService.listStudents();
export const getTeachers = () => teachersService.listTeachers();
export const getPayments = () => paymentsService.listAllPayments();
export const getActualites = () => announcementsService.listAnnouncements();
export const getClasses = () => academicService.listClasses();
export const getFilieres = () => academicService.listFilieres();

// ---- Lookups utilisés par le module Étudiants ----
export const getStudentById = (id: string) => studentsService.getStudent(id);
export const getPaymentsByStudent = (studentId: string) => paymentsService.listPaymentsForStudent(studentId);
export const getGradesByStudent = (studentId: string) => gradesService.listGradesForStudent(studentId);

// Lookups synchrones : lisent le cache déjà chargé par useAcademicStore.init()
// (déclenché par DashboardShell au montage), exactement comme l'ancien
// mock-data.ts lisait ses tableaux en mémoire de façon synchrone.
export const getClasseById = (id: string) =>
  useAcademicStore.getState().classes.find((c) => c.id === id) ?? null;

export const getFiliereById = (id: string) =>
  useAcademicStore.getState().filieres.find((f) => f.id === id) ?? null;

export const getStudentsByClasse = (classeId: string) =>
  useAcademicStore.getState().students.filter((s) => s.classeId === classeId);

// ---- Lookups utilisés par le module Professeurs ----
export const getTeacherById = (id: string) => teachersService.getTeacher(id);
export const getScheduleByTeacher = (teacherId: string) => schedulesService.listScheduleByTeacher(teacherId);
