import { create } from "zustand";
import type { Filiere, Classe, Student, Teacher, Attendance, AttendanceStatus, Grade } from "./types";
import * as academicService from "./services/academic.service";
import * as studentsService from "./services/students.service";
import * as teachersService from "./services/teachers.service";
import * as attendanceService from "./services/attendance.service";
import * as gradesService from "./services/grades.service";

function genId(prefix: string) {
  return `${prefix}-${Math.random().toString(36).slice(2, 9)}`;
}

interface AcademicStore {
  filieres: Filiere[];
  classes: Classe[];
  students: Student[];
  teachers: Teacher[];
  attendance: Attendance[];
  grades: Grade[];
  loading: boolean;
  loaded: boolean;

  /** Charge toutes les données réelles depuis Supabase. À appeler une fois au montage du dashboard. */
  init: () => Promise<void>;

  addFiliere: (data: Omit<Filiere, "id">) => void;
  updateFiliere: (id: string, data: Omit<Filiere, "id">) => void;
  deleteFiliere: (id: string) => void;

  addClasse: (data: Omit<Classe, "id">) => void;
  updateClasse: (id: string, data: Omit<Classe, "id">) => void;
  deleteClasse: (id: string) => void;

  assignProfesseurPrincipal: (classeId: string, professeurId: string | undefined) => void;
  reassignStudentClasse: (studentId: string, classeId: string) => void;

  markAttendance: (
    personId: string,
    personType: "etudiant" | "professeur",
    date: string,
    status: AttendanceStatus,
    classeId?: string
  ) => void;

  upsertGrade: (data: Omit<Grade, "id"> & { id?: string }) => void;
  deleteGrade: (id: string) => void;
}

// Chaque action met à jour l'état local immédiatement (UX inchangée, aucun
// écran de chargement supplémentaire) PUIS persiste en arrière-plan sur
// Supabase. En cas d'échec réseau/RLS, une erreur est journalisée en
// console et l'optimistic update est annulé quand c'est possible.
export const useAcademicStore = create<AcademicStore>((set, get) => ({
  filieres: [],
  classes: [],
  students: [],
  teachers: [],
  attendance: [],
  grades: [],
  loading: false,
  loaded: false,

  init: async () => {
    if (get().loaded || get().loading) return;
    set({ loading: true });
    try {
      const [filieres, classes, students, teachers] = await Promise.all([
        academicService.listFilieres(),
        academicService.listClasses(),
        studentsService.listStudents(),
        teachersService.listTeachers(),
      ]);
      set({ filieres, classes, students, teachers, loading: false, loaded: true });
    } catch (err) {
      console.error("Échec du chargement des données Supabase :", err);
      set({ loading: false });
    }
  },

  addFiliere: (data) => {
    const optimistic: Filiere = { ...data, id: genId("f") };
    set((s) => ({ filieres: [...s.filieres, optimistic] }));
    academicService.createFiliere(data).catch((err) => {
      console.error("addFiliere:", err);
      set((s) => ({ filieres: s.filieres.filter((f) => f.id !== optimistic.id) }));
    });
  },

  updateFiliere: (id, data) => {
    set((s) => ({ filieres: s.filieres.map((f) => (f.id === id ? { ...f, ...data } : f)) }));
    academicService.updateFiliere(id, data).catch((err) => console.error("updateFiliere:", err));
  },

  deleteFiliere: (id) => {
    set((s) => ({ filieres: s.filieres.filter((f) => f.id !== id) }));
    academicService.deleteFiliere(id).catch((err) => console.error("deleteFiliere:", err));
  },

  addClasse: (data) => {
    const optimistic: Classe = { ...data, id: genId("c") };
    set((s) => ({ classes: [...s.classes, optimistic] }));
    academicService.createClasse(data).catch((err) => {
      console.error("addClasse:", err);
      set((s) => ({ classes: s.classes.filter((c) => c.id !== optimistic.id) }));
    });
  },

  updateClasse: (id, data) => {
    set((s) => ({ classes: s.classes.map((c) => (c.id === id ? { ...c, ...data } : c)) }));
    academicService.updateClasse(id, data).catch((err) => console.error("updateClasse:", err));
  },

  deleteClasse: (id) => {
    set((s) => ({ classes: s.classes.filter((c) => c.id !== id) }));
    academicService.deleteClasse(id).catch((err) => console.error("deleteClasse:", err));
  },

  assignProfesseurPrincipal: (classeId, professeurId) => {
    set((s) => ({
      classes: s.classes.map((c) => (c.id === classeId ? { ...c, professeurPrincipalId: professeurId } : c)),
    }));
    teachersService.setPrincipalTeacher(classeId, professeurId).catch((err) => console.error("assignProfesseurPrincipal:", err));
  },

  reassignStudentClasse: (studentId, classeId) => {
    set((s) => ({
      students: s.students.map((st) => (st.id === studentId ? { ...st, classeId } : st)),
    }));
    studentsService.reassignStudentClasse(studentId, classeId).catch((err) => console.error("reassignStudentClasse:", err));
  },

  // Une entrée par (personId, date, personType) : on remplace si elle existe déjà pour ce jour.
  markAttendance: (personId, personType, date, status, classeId) => {
    set((s) => {
      const existingIndex = s.attendance.findIndex(
        (a) => a.personId === personId && a.personType === personType && a.date === date
      );
      const entry: Attendance = {
        id: existingIndex >= 0 ? s.attendance[existingIndex].id : genId("att"),
        personId,
        personType,
        date,
        status,
        classeId,
      };
      if (existingIndex >= 0) {
        const next = [...s.attendance];
        next[existingIndex] = entry;
        return { attendance: next };
      }
      return { attendance: [...s.attendance, entry] };
    });
    attendanceService
      .markAttendance({ personId, personType, date, status, classeId })
      .catch((err) => console.error("markAttendance:", err));
  },

  // Remplace la note existante pour (studentId, matiere, type, date) sinon en crée une nouvelle.
  upsertGrade: (data) => {
    set((s) => {
      const existingIndex = data.id
        ? s.grades.findIndex((g) => g.id === data.id)
        : s.grades.findIndex(
            (g) =>
              g.studentId === data.studentId &&
              g.matiere === data.matiere &&
              g.type === data.type &&
              g.date === data.date
          );
      const entry: Grade = { ...data, id: data.id ?? (existingIndex >= 0 ? s.grades[existingIndex].id : genId("g")) };
      if (existingIndex >= 0) {
        const next = [...s.grades];
        next[existingIndex] = entry;
        return { grades: next };
      }
      return { grades: [...s.grades, entry] };
    });
    gradesService
      .upsertGrade({
        studentId: data.studentId,
        matiere: data.matiere,
        type: data.type,
        note: data.note,
        bareme: data.bareme,
        coefficient: data.coefficient,
        date: data.date,
        professeurId: data.professeurId,
      })
      .catch((err) => console.error("upsertGrade:", err));
  },

  deleteGrade: (id) => {
    set((s) => ({ grades: s.grades.filter((g) => g.id !== id) }));
    gradesService.deleteGrade(id).catch((err) => console.error("deleteGrade:", err));
  },
}));
