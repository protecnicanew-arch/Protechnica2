import type { LucideIcon } from "lucide-react";
import {
  LayoutDashboard,
  GraduationCap,
  Users,
  School,
  Layers,
  CalendarCheck,
  CalendarClock,
  ClipboardList,
  FileText,
  Wallet,
  Calculator,
  Library,
  Newspaper,
  Settings,
  History,
  Home,
  CreditCard,
  UserCircle,
} from "lucide-react";
import type { Resource } from "./auth/permissions";

export interface NavItem {
  label: string;
  href: string;
  icon: LucideIcon;
  /** Ressource de permissions associée — si absente, l'item est toujours visible (dashboard, profil). */
  resource?: Resource;
}

// Menu latéral (desktop / tablette)
export const sidebarNav: NavItem[] = [
  { label: "Tableau de bord", href: "/dashboard", icon: LayoutDashboard },
  { label: "Étudiants", href: "/dashboard/etudiants", icon: GraduationCap, resource: "etudiants" },
  { label: "Professeurs", href: "/dashboard/professeurs", icon: Users, resource: "professeurs" },
  { label: "Classes", href: "/dashboard/classes", icon: School, resource: "classes" },
  { label: "Filières", href: "/dashboard/filieres", icon: Layers, resource: "filieres" },
  { label: "Présences", href: "/dashboard/presences", icon: CalendarCheck, resource: "presences" },
  { label: "Notes & Examens", href: "/dashboard/notes", icon: ClipboardList, resource: "notes" },
  { label: "Emploi du temps", href: "/dashboard/emploi-temps", icon: CalendarClock, resource: "emploi_temps" },
  { label: "Bulletins", href: "/dashboard/bulletins", icon: FileText, resource: "bulletins" },
  { label: "Paiements", href: "/dashboard/paiements", icon: Wallet, resource: "paiements" },
  { label: "Comptabilité", href: "/dashboard/comptabilite", icon: Calculator, resource: "comptabilite" },
  { label: "Bibliothèque", href: "/dashboard/bibliotheque", icon: Library, resource: "bibliotheque" },
  { label: "Actualités", href: "/dashboard/actualites", icon: Newspaper, resource: "actualites" },
  { label: "Paramètres", href: "/dashboard/parametres", icon: Settings, resource: "parametres" },
  { label: "Journal d'audit", href: "/dashboard/audit", icon: History, resource: "audit" },
];

// Barre de navigation inférieure (mobile)
export const mobileNav: NavItem[] = [
  { label: "Accueil", href: "/dashboard", icon: Home },
  { label: "Étudiants", href: "/dashboard/etudiants", icon: GraduationCap, resource: "etudiants" },
  { label: "Paiements", href: "/dashboard/paiements", icon: CreditCard, resource: "paiements" },
  { label: "Actualités", href: "/dashboard/actualites", icon: Newspaper, resource: "actualites" },
  { label: "Profil", href: "/dashboard/profil", icon: UserCircle },
];
